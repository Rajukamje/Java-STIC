# ShipTransfer Marine Insurance Portal - Python (Flask)

    python -m venv venv
    venv\Scripts\activate          (Windows)      source venv/bin/activate   (Mac/Linux)
    pip install -r requirements.txt
    python run.py                  -> open the address it prints (normally http://localhost:5000)

If port 5000 is blocked or busy (Windows error 10013) run.py automatically uses the next free port and prints it.
Optional: set PORT=8080 first (Windows: set PORT=8080), HOST=0.0.0.0 to open the site to other computers.
Tip (Windows): keep the project folder outside OneDrive/Dropbox - syncing can lock the database file.

Demo logins (choose the matching login type; all broker/client demo accounts use the same password pattern):
admin@portal.com / Admin@123 | broker@portal.com / Broker@123 (also maria@portal.com, tom@portal.com) | client@portal.com / Client@123

## The insurance process
1. Client registers, picks a broker in "Find a Broker" (ratings + reviews), or an admin assigns one.
2. Broker collects client information + required documents (ID/registration, ship registry, class certificate, survey report) in the Client File and verifies them -> KYC Verified.
3. Plan + quote (Hull, Cargo ICC A/B/C, Liability, Builder's Risk, Inland) -> policy -> invoice (pay + PDF).
4. Certificate request -> admin approves -> PDF with QR code (email / download / copy / print / verify page).
5. Notifications 30 / 15 / 7 days before a policy or certificate expires -> Renew button. Overdue invoices also notify.
6. Claims: report -> Under Review -> Approved -> Paid (or Rejected), evidence upload.
7. Dashboards with pie, donut, column, line and bar charts for each role. Audit log for admins.

## Chatbot (Cognigy.AI)
Every page opens the Cognigy webchat (project "Insurance Risk Guardian AI"); if Cognigy cannot be reached the old rule-based help bubble is used.
Browser side: js/cognigy-bot.js.  Server side: portal/routes/cognigy.py (/api/chat/* for the browser, /api/bot/* for Cognigy).
Settings: portal/config.py (COGNIGY_ENDPOINT_URL, COGNIGY_API_KEY in data/bot.key).  **What to change inside Cognigy: COGNIGY_SETUP.md.**  Tests: python tests/test_cognigy.py

## Security
Hashed passwords, 5-failed-login lock, session renewed at login, HttpOnly + SameSite cookie, CSRF token on every change request, rate limit on login/register/reset,
security headers (CSP, nosniff, frame protection), role checks on the server for every request, upload checks (type, real file content, 8 MB, random file names, access-checked download),
parameterized SQL, HTML escaping. For production: set SECRET_KEY, HTTPS=1, DEMO_MODE=0 and run behind https (e.g. gunicorn + nginx).

## Folder map
    run.py                      start the website            requirements.txt   flask, reportlab
    portal/                     BACKEND (Python)
      config.py                 settings          security.py   cookie, CSRF, headers, rate limit
      schema.sql                DATABASE tables   seed.py       tables, upgrades for old databases, demo data, plans
      core.py                   shared helpers: database, roles, scope, quotes, invoices, reminders
      pdf_service.py            certificate PDF + QR, invoice PDF, email sending
      routes/                   auth, dashboard, people (clients+brokers), plans, policies, certificates, claims,
                                invoices, reviews, documents, records, helpbot, cognigy (chatbot API), extras (reset password, notifications, contact, newsletter)
    static/                     FRONTEND
      *.html                    one file per page (public: index, plans, verify, insights, contact, privacy, terms, login, register ...)
      css/style.css             all styling (light + dark mode)
      js/api.js layout.js charts.js cognigy-bot.js (help-bot.js = fallback)    shared scripts (layout.js draws sidebar, HEADER and FOOTER)
      js/pages/<page>.js        logic of each page
    data/                       portal.db, pdfs/, uploads/ (created automatically)

Emails: set SMTP_HOST (+ SMTP_PORT, SMTP_USER, SMTP_PASS, SMTP_FROM) to send real emails, otherwise they are logged as notifications.
Existing databases from the previous version are upgraded automatically at startup.
