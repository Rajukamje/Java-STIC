/* pages/notifications.js - Notifications: emails sent by the portal + policy expiry reminders (30/15/7 days) */
async function initPage() {
  const rows = await api("/api/notifications");
  const icon = t => t === "reminder" ? "⏰" : t.includes("certificate") ? "📄" : t.includes("password") ? "🔑" : "🔔";
  $("#main").innerHTML = `<h1>Notifications</h1><div class="card">` +
    (rows.map(n => `<div class="note-row"><span class="ico">${icon(n.type)}</span><div><b>${esc(n.type)}</b><br>${esc(n.detail)}<br><small>${esc(n.sent_at)}</small></div></div>`).join("") || "Nothing yet.") + `</div>`;
}
