/* pages/clients.js - Clients (Broker + Admin): table with search; opens the client file; admin assigns a broker */

async function initPage() {
  const rows = await api("/api/clients"), brokers = ME.role === "admin" ? await api("/api/brokers") : [];
  $("#main").innerHTML = `<h1>${ME.role === "admin" ? "Clients" : "My Clients"}</h1><div class="card"><input id="search" placeholder="Search..." oninput="filterRows(this.value)"><div id="ct">` +
    table(["Name", "Company", "Email", "Country", "Broker", "Policies", "KYC", ""], rows, c => `<tr><td>${esc(c.name)}</td><td>${esc(c.company)}</td><td>${esc(c.email)}</td><td>${esc(c.country)}</td>
      <td>${ME.role === "admin" ? `<select onchange="assign(${c.id}, this.value)"><option value="">Unassigned</option>${options(brokers.map(b => [b.id, b.company || b.name]), c.broker_id)}</select>` : esc(c.broker)}</td>
      <td>${c.policies}</td><td>${badge(c.kyc_status)}</td><td><a class="btn pill sm" href="clientfile.html?id=${c.id}">Open file</a></td></tr>`) + `</div></div>`;
}
// Hide table rows that do not contain the search text
const filterRows = text => document.querySelectorAll("#ct tr + tr").forEach(r => r.style.display = r.textContent.toLowerCase().includes(text.toLowerCase()) ? "" : "none");
const assign = (id, broker_id) => act(() => api("/api/clients/" + id, "PUT", { broker_id }), "Broker assigned");
