/* pages/claims.js - Claims: report a loss, follow the status, upload evidence, admin review
   Flow: Submitted -> Under Review -> Approved -> Paid   (or Rejected) */

let CLAIMS = [];

async function initPage() {
  const [data, pols] = await Promise.all([api("/api/claims"), api("/api/policies")]);
  CLAIMS = data.rows;
  $("#main").innerHTML = `<h1>Claims</h1>
    <div class="card"><details><summary><b>+ Report a claim</b></summary><form class="f" onsubmit="sub(event, addClaim)">
      <label>Policy<select name="policy_id">${options(pols.filter(p => p.status !== "Cancelled").map(p => [p.id, p.policy_number + " - " + p.ship_name]))}</select></label>
      <label>Incident type<select name="incident_type">${options(data.types)}</select></label><label>Incident date<input name="incident_date" type="date" max="${new Date().toISOString().slice(0, 10)}" required></label>
      <label>Amount claimed (USD)<input name="amount_claimed" type="number" min="1" required></label><label style="grid-column:1/-1">What happened?<input name="description" required minlength="10"></label>
      <button>Submit claim</button></form><small>Upload photos and reports afterwards with "Evidence" in the table.</small></details></div>
    <div class="card">` + table(["Claim", "Policy / Ship", "Client", "Type", "Incident", "Claimed", "Approved", "Status", "Actions"], CLAIMS, c => `<tr><td>${c.claim_number}</td><td>${c.policy_number}<br><small>${esc(c.ship_name)}</small></td>
      <td>${esc(c.client)}</td><td>${esc(c.incident_type)}</td><td>${c.incident_date}</td><td>${money(c.amount_claimed)}</td><td>${c.amount_approved ? money(c.amount_approved) : "-"}</td>
      <td>${badge(c.status)}${c.decision_note ? `<br><small>${esc(c.decision_note)}</small>` : ""}</td>
      <td><button class="sm alt" onclick="evidence(${c.id})">📎 Evidence</button>${ME.role === "admin" && c.next.length ? `<button class="sm" onclick="reviewClaim(${c.id})">Review</button>` : ""}</td></tr>`) + `</div>`;
}

const addClaim = d => act(async () => { const r = await api("/api/claims", "POST", d); toast("Claim " + r.claim_number + " submitted"); setTimeout(() => location.reload(), 1200); });

// Upload evidence (photo / report) for one claim: opens the file chooser, then POST /api/documents
function evidence(id) {
  const c = CLAIMS.find(x => x.id === id), input = document.createElement("input"); input.type = "file";
  input.onchange = () => act(async () => {
    const f = new FormData(); f.append("file", input.files[0]); f.append("doc_type", "Claim evidence (photos / report)"); f.append("claim_id", c.id); f.append("policy_id", c.policy_id); f.append("client_id", c.client_id);
    await upload("/api/documents", f);
  }, "Evidence uploaded");
  input.click();
}

// Admin: dialog to move the claim to the next status
function reviewClaim(id) {
  const c = CLAIMS.find(x => x.id === id);
  $("#dlg").innerHTML = `<h2>Review ${c.claim_number}</h2><p>${esc(c.incident_type)} on ${c.incident_date}, claimed ${money(c.amount_claimed)}<br><small>${esc(c.description)}</small></p>
    <form class="f" style="grid-template-columns:1fr" onsubmit="sub(event, d => saveReview(${id}, d))"><label>New status<select name="status">${options(c.next)}</select></label>
    <label>Approved amount (only for Approved)<input name="amount_approved" type="number" value="${c.amount_claimed}"></label><label>Decision note (needed for Rejected)<input name="decision_note"></label>
    <button>Save</button><button type="button" class="alt" onclick="$('#dlg').close()">Close</button></form>`;
  $("#dlg").showModal();
}
const saveReview = (id, d) => act(async () => { await api("/api/claims/" + id, "PUT", d); location.reload(); }, "Claim updated");
