/* pages/clientfile.js - The client file: client information, KYC status, required-documents checklist and uploaded documents.
   Client: own file ("My Documents").  Broker / Admin: opened with ?id=CLIENT_ID from the Clients page. */

let FILE = null;
const CID = new URLSearchParams(location.search).get("id");

async function initPage() {
  FILE = await api("/api/clientfile" + (CID ? "?id=" + CID : ""));
  const c = FILE.client, staff = FILE.staff;
  $("#main").innerHTML = `<h1>${esc(c.company || c.name)} ${badge(c.kyc_status)}</h1>
    <p>${esc(c.name)} · ${esc(c.email)} · ${esc(c.phone)} · Broker: <b>${esc(c.broker)}</b></p>
    ${staff ? `<p><button class="sm" onclick="setKyc('Verified')">✅ Mark KYC verified</button><button class="sm alt" onclick="setKyc('Pending')">Set pending</button><button class="sm red" onclick="setKyc('Rejected')">Reject</button>
      <small> "Verified" needs all required documents verified.</small></p>` : ""}
    <div class="grid">
      <div class="card"><b>Client information</b><form class="f" style="grid-template-columns:1fr" onsubmit="sub(event, saveProfile)">
        <label>Company registration no.<input name="reg_no" value="${esc(c.reg_no)}"></label><label>Country<input name="country" value="${esc(c.country)}"></label>
        <label>Contact person<input name="contact_person" value="${esc(c.contact_person)}"></label><label>Notes<input name="notes" value="${esc(c.notes)}"></label><button>Save</button></form></div>
      <div class="card"><b>Required documents</b><br><br>${FILE.required.map(r => `${badge(r.status)} ${esc(r.type)}`).join("<br>")}</div>
      <div class="card"><b>Upload a document</b><form class="f" style="grid-template-columns:1fr" onsubmit="doUpload(event)"><input type="hidden" name="client_id" value="${c.id}">
        <label>Type<select name="doc_type">${options(FILE.doc_types)}</select></label><label>Policy (optional)<select name="policy_id"><option value="">-</option>${options(FILE.policies.map(p => [p.id, p.policy_number]))}</select></label>
        <label>File (pdf, png, jpg, docx, xlsx; max 8 MB)<input type="file" name="file" required></label><button>Upload</button></form></div></div>
    <div class="card"><b>Documents</b>` + table(["Type", "File", "Status", "Uploaded", ""], FILE.documents, d => `<tr><td>${esc(d.doc_type)}</td><td>${esc(d.filename)}</td><td>${badge(d.status)}${d.note ? `<br><small>${esc(d.note)}</small>` : ""}</td><td>${d.uploaded_at.slice(0, 10)}</td>
      <td><a class="btn pill sm" href="/api/documents/${d.id}/file">Download</a>${staff ? `<button class="sm" onclick="review(${d.id},'Verified')">Verify</button><button class="sm red" onclick="review(${d.id},'Rejected')">Reject</button>` : ""}
      ${d.status === "Pending" ? `<button class="sm alt" onclick="removeDoc(${d.id})">Remove</button>` : ""}</td></tr>`) + `</div>
    <div class="grid"><div class="card"><b>Policies</b><br><br>${FILE.policies.map(p => `${p.policy_number} ${badge(p.status)} <small>${esc(p.ship_name)}</small>`).join("<br>") || "None yet"}</div>
      <div class="card"><b>Claims</b><br><br>${FILE.claims.map(c => `${c.claim_number} ${badge(c.status)} <small>${esc(c.incident_type)} ${money(c.amount_claimed)}</small>`).join("<br>") || "None"}</div></div>`;
}

const doUpload = e => { e.preventDefault(); act(async () => { await upload("/api/documents", new FormData(e.target)); location.reload(); }, "Document uploaded"); };
const saveProfile = d => act(async () => { await api("/api/clientfile", "PUT", { ...d, client_id: FILE.client.id }); location.reload(); }, "Saved");
const setKyc = status => act(async () => { await api("/api/clientfile/kyc", "POST", { client_id: FILE.client.id, status }); location.reload(); }, "KYC status updated");
const review = (id, status) => { const note = status === "Rejected" ? prompt("Why is the document rejected?") : ""; if (status === "Rejected" && !note) return;
  act(async () => { await api(`/api/documents/${id}/review`, "POST", { status, note }); location.reload(); }, "Document " + status.toLowerCase()); };
const removeDoc = id => confirm("Remove this document?") && act(async () => { await api("/api/documents/" + id, "DELETE"); location.reload(); }, "Removed");
