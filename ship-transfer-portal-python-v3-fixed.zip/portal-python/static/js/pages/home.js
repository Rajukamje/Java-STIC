/* pages/home.js - Landing page: loads the public numbers (GET /api/stats) and counts them up */
(async function () {
  try {
    const s = await api("/api/stats");
    document.querySelectorAll("[data-stat]").forEach(el => {
      const target = s[el.dataset.stat] || 0; let n = 0;
      const timer = setInterval(() => { n = Math.min(target, n + Math.ceil(target / 20)); el.textContent = n; if (n >= target) clearInterval(timer); }, 40);
    });
  } catch (e) { /* numbers are optional */ }
})();
