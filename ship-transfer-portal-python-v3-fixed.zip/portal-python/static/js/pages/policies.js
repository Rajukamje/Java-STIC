/* pages/policies.js - Policies: new policy form (premium is calculated by the server), list, renew, cancel */

async function initPage() {
  const [rows, plans] = await Promise.all([api("/api/policies"), api("/api/plans")]);
  const clients = ME.role === "client" ? [] : await api("/api/clients");
  const pre = new URLSearchParams(location.search).get("plan");
  $("#main").innerHTML = `<h1>Policies</h1>
    <div class="card"><details ${pre ? "open" : ""}><summary><b>+ New policy</b> (premium is calculated from the plan)</summary>
      <form class="f" id="pform" onsubmit="sub(event, addPolicy)">
        ${ME.role === "client" ? "" : `<label>Client<select name="client_id">${options(clients.map(c => [c.id, c.company || c.name]))}</select></label>`}
        <label>Plan<select name="plan_id">${options(plans.map(p => [p.id, p.name + " (" + p.rate + "%)"]), pre)}</select></label>
        <label>Ship name<input name="ship_name" required></label><label>IMO (7 digits)<input name="imo" required pattern="\\d{7}"></label><label>Flag<input name="flag"></label>
        <label>Ship type<input name="ship_type" value="General cargo"></label><label>Tonnage (GT)<input name="tonnage" type="number"></label><label>Year built<input name="year_built" type="number" placeholder="2012"></label>
        <label>Sum insured (USD)<input name="sum_insured" type="number" min="1" required></label><label>Start<input name="start_date" type="date" required></label><label>End<input name="end_date" type="date" required></label>
        <label><input type="checkbox" name="war_strikes" style="width:auto"> War &amp; strikes (+0.05%)</label><label><input type="checkbox" name="bbb" style="width:auto"> Build Back Better (+0.04%)</label>
        <button type="button" class="alt" onclick="getQuote()">Get quote</button><button>Save policy</button></form><div id="quoteBox"></div></details></div>
    <div class="card">` + table(["Policy", "Client", "Ship", "Plan", "Sum insured", "Premium", "Period", "Status", ""], rows, p => `<tr><td>${p.policy_number}</td><td>${esc(p.client)}</td><td>${esc(p.ship_name)}</td><td>${esc(p.type)}</td>
      <td>${p.sum_insured ? money(p.sum_insured) : "-"}</td><td>${money(p.premium)}</td><td>${p.start_date}<br>to ${p.end_date}</td><td>${badge(p.status)}${p.days_left >= 0 && p.days_left <= 60 ? `<br><small>${p.days_left} days left</small>` : ""}</td>
      <td>${p.status !== "Cancelled" && p.days_left <= 60 && !p.renewed ? `<button class="sm" onclick="renewPolicy(${p.id})">🔁 Renew</button>` : p.renewed ? "<small>Renewed</small>" : ""}
      ${ME.role === "admin" && p.status !== "Cancelled" ? `<button class="sm red" onclick="cancelPolicy(${p.id})">Cancel</button>` : ""}</td></tr>`) + `</div>`;
}

// Quote for the data typed in the form (nothing is saved)
const getQuote = () => act(async () => {
  const r = await api("/api/quote", "POST", Object.fromEntries(new FormData($("#pform"))));
  $("#quoteBox").innerHTML = `<div class="note">Base ${money(r.base)} (rate ${r.rate}%) | ship age +${r.age_load * 100}% | claims +${r.claims_load * 100}%<br><b>Premium ${money(r.premium)}</b> | Deductible ${money(r.deductible)}</div>`;
});
const addPolicy = d => act(async () => { const r = await api("/api/policies", "POST", d); toast(`Policy ${r.policy_number} created. Premium ${money(r.premium)}. Invoice issued.`); setTimeout(() => location.href = "invoices.html", 1200); });
const renewPolicy = id => confirm("Renew this policy for one more year?") && act(async () => { const r = await api(`/api/policies/${id}/renew`, "POST"); toast(`Renewed as ${r.policy_number} (premium ${money(r.premium)}). Invoice issued.`); setTimeout(() => location.reload(), 1500); });
const cancelPolicy = id => confirm("Cancel this policy?") && act(async () => { await api(`/api/policies/${id}/cancel`, "POST"); location.reload(); }, "Policy cancelled");
