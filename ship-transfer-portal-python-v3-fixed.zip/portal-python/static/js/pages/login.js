/* pages/login.js - Login page. The page HTML is written directly in login.html */

// Login form: POST /api/login, then open the dashboard
const doLogin=d=>act(async()=>{await api("/api/login","POST",d);location.href="dashboard.html";});
