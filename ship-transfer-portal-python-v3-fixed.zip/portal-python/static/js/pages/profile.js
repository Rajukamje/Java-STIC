/* pages/profile.js - Profile page: edit profile and change password. Draws into <main id="main">. */
// Builds the HTML of this page (ME = logged-in user, defined in layout.js; helpers table/badge/money/esc/api come from api.js)
const render = ()=>`<h1>Profile</h1><div class="grid"><div class="card"><form class="f" style="grid-template-columns:1fr" onsubmit="sub(event,saveProfile)"><label>Name<input name="name" value="${esc(ME.name)}"></label>
  <label>Phone<input name="phone" value="${esc(ME.phone)}"></label><label>Company<input name="company" value="${esc(ME.company)}"></label><label>Address<input name="address" value="${esc(ME.address)}"></label>
  <label>Email (cannot change)<input value="${esc(ME.email)}" disabled></label><label>Role<input value="${ME.role}" disabled></label><button>Save</button></form></div>
  <div class="card"><b>Change password</b><form class="f" style="grid-template-columns:1fr" onsubmit="sub(event,changePw)"><input name="old" type="password" placeholder="Old password" required>
  <input name="new" type="password" placeholder="New password" required><input name="confirm" type="password" placeholder="Confirm new password" required><button>Change password</button></form></div></div>`;

// layout.js calls this after the login check passed
async function initPage() { document.getElementById("main").innerHTML = await render(); }

// Save profile form (email and role cannot be changed)
const saveProfile=d=>act(async()=>{await api("/api/profile","PUT",d);ME=(await api("/api/me")).user;location.reload()},"Profile saved");

// Change-password form
const changePw=(d,f)=>act(async()=>{await api("/api/password","POST",d);f.reset()},"Password changed");
