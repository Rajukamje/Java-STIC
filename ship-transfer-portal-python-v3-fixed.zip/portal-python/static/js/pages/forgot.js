/* pages/forgot.js - Forgot password: asks the server for a reset link */
const doForgot = d => act(async () => {
  const r = await api("/api/forgot", "POST", d);
  $("#result").innerHTML = `<div class="note">${esc(r.message)}${r.demo_link ? `<br><br><b>Demo mode:</b> <a href="${r.demo_link}">open the reset link</a>` : ""}</div>`;
});
