/* pages/directory.js - Broker directory: ratings and reviews. Clients can choose a broker and review the broker they worked with. */

let BROKERS = [];

async function initPage() {
  BROKERS = await api("/api/directory");
  const isClient = ME.role === "client";
  $("#main").innerHTML = `<h1>${isClient ? "Find a Broker" : "Broker Reviews"}</h1><div class="grid">` + BROKERS.map(b => `
    <div class="card"><h3 style="margin:0">${esc(b.company || b.name)}</h3><small>${esc(b.name)} · ${esc(b.category)} · ${b.clients} clients</small>
      <p class="stars">${stars(b.avg)} <b>${b.avg || "-"}</b> <small>(${b.count} reviews)</small></p>
      ${b.reviews.map(r => `<div class="review"><span class="stars">${stars(r.rating)}</span> <small>${esc(r.client)}</small><br>${esc(r.comment) || "<i>No comment</i>"}</div>`).join("") || "<small>No reviews yet.</small>"}
      ${isClient ? `<p>${b.mine ? badge("Active") + " <small>Your broker</small>" : `<button class="sm" onclick="choose(${b.id})">Choose this broker</button>`}
        ${b.can_review ? `<button class="sm alt" onclick="reviewDialog(${b.id})">★ Write a review</button>` : ""}</p>` : ""}</div>`).join("") + `</div>`;
}

const choose = id => confirm("Choose this broker? He will collect your information and documents.") && act(async () => { await api("/api/me/broker", "POST", { broker_id: id }); location.reload(); }, "Broker chosen");
function reviewDialog(id) {
  $("#dlg").innerHTML = `<h2>Review this broker</h2><form class="f" style="grid-template-columns:1fr" onsubmit="sub(event, d => saveReview(${id}, d))"><label>Rating<select name="rating">${options([[5, "★★★★★ Excellent"], [4, "★★★★ Good"], [3, "★★★ OK"], [2, "★★ Poor"], [1, "★ Bad"]])}</select></label>
    <label>Comment (optional, max 500)<input name="comment" maxlength="500"></label><button>Save review</button><button type="button" class="alt" onclick="$('#dlg').close()">Close</button></form>`;
  $("#dlg").showModal();
}
const saveReview = (id, d) => act(async () => { await api(`/api/brokers/${id}/reviews`, "POST", d); location.reload(); }, "Thank you for your review");
