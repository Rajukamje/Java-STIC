/* pages/dashboard.js - Dashboard: number cards + charts (pie, donut, column, line, bars), different for Client / Broker / Admin.
   Data comes from GET /api/dashboard. Charts are drawn by charts.js */

const CARD_ICONS = { "Policies": "📑", "Certificates": "📄", "Pending approval": "⏳", "Open claims": "🧾", "Outstanding invoices (USD)": "💳",
                     "Clients": "🧑‍💼", "Brokers": "🤝", "Documents to verify": "🗂️", "Documents missing": "📎" };
const QUICK = {   // quick action buttons per role
  client: [["policies.html", "➕ New policy"], ["claims.html", "🧾 Report a claim"], ["clientfile.html", "📎 My documents"], ["directory.html", "⭐ Find a broker"]],
  broker: [["clients.html", "🧑‍💼 My clients"], ["policies.html", "📑 Policies"], ["claims.html", "🧾 Claims"], ["directory.html", "⭐ My reviews"]],
  admin:  [["certificates.html", "✅ Approve certificates"], ["claims.html", "🧾 Review claims"], ["brokers.html", "🤝 Brokers"], ["plans.html", "💼 Plans"]]
};

async function initPage() {
  const d = await api("/api/dashboard");
  const cards = Object.entries(d.cards).map(([k, v]) =>
    `<div class="card stat-card"><div class="ico">${CARD_ICONS[k] || "📊"}</div><div>${k}<div class="big">${Number(v).toLocaleString()}</div></div></div>`).join("");
  const quick = QUICK[ME.role].map(([h, t]) => `<a class="btn pill" href="${h}">${t}</a>`).join(" ");
  const alerts = d["Expiring soon"].map(a => `⏰ ${esc(a)}`).join("<br>") || "Nothing expires in the next 30 days.";
  $("#main").innerHTML = `<h1>${ME.role[0].toUpperCase() + ME.role.slice(1)} Dashboard</h1><div class="grid">${cards}</div>
    <div class="grid">
      ${pie("Policies by status", d["Policies by status"])}
      ${donut("Claims by status", d["Claims by status"])}
      ${pie("Invoices by status", d["Invoices by status"])}
      ${columns("Premium by month (USD)", d["Premium by month (USD)"])}
      ${columns("Claims vs premium (USD)", d["Claims vs premium (USD)"])}
      ${line("Certificates per month", d["Certificates per month"])}
      ${bars("Policies by plan", d["Policies by plan"])}
      ${d["Top brokers by premium"] ? bars("Top brokers by premium", d["Top brokers by premium"]) : ""}
    </div>
    <div class="grid"><div class="card"><b>Quick actions</b><br><br>${quick}</div><div class="card"><b>Expiry alerts (policies and certificates)</b><br><br>${alerts}<br><br><a href="notifications.html">See all notifications</a></div></div>`;
}
