/* pages/inbox.js - Admin inbox: messages from the contact form + number of newsletter subscribers */
async function initPage() {
  const d = await api("/api/messages");
  $("#main").innerHTML = `<h1>Inbox</h1><p>📬 Newsletter subscribers: <b>${d.subscribers}</b></p><div class="card">` +
    table(["Date", "Name", "Email", "Topic", "Message"], d.messages, m => `<tr><td>${m.created_at.slice(0, 16).replace("T", " ")}</td><td>${esc(m.name)}</td><td>${esc(m.email)}</td><td>${esc(m.topic)}</td><td>${esc(m.message)}</td></tr>`) + `</div>`;
}
