/* pages/plans.js - Insurance plans (public): plan cards by category, premium quote calculator, admin add / edit */

let PLANS = [];

async function initPage() {
  const admin = ME && ME.role === "admin";
  PLANS = await api("/api/plans" + (admin ? "?all=1" : ""));
  const cat = new URLSearchParams(location.search).get("cat") || "All";
  const cats = ["All", ...new Set(PLANS.map(p => p.category))];
  const chips = cats.map(c => `<a class="chip ${c === cat ? "solid" : ""}" href="plans.html?cat=${c}">${c}</a>`).join(" ");
  const cards = PLANS.filter(p => cat === "All" || p.category === cat).map(p => `
    <div class="card plan ${p.active ? "" : "off"}"><span class="badge">${esc(p.category)}</span> ${p.active ? "" : badge("Inactive")}
      <h3>${esc(p.name)}</h3><p>${esc(p.description)}</p><p><small><b>Covers:</b> ${esc(p.covers)}</small></p>
      <p>Rate <b>${p.rate}%</b> of sum insured &nbsp;|&nbsp; Deductible <b>${money(p.deductible)}</b></p>
      <a class="btn pill" href="${ME ? "policies.html?plan=" + p.id : "register.html"}">${ME ? "Get this plan" : "Register to apply"}</a>
      ${admin ? `<button class="sm alt" onclick="editPlan(${p.id})">Edit rate</button><button class="sm ${p.active ? "red" : ""}" onclick="togglePlan(${p.id})">${p.active ? "Switch off" : "Switch on"}</button>` : ""}
    </div>`).join("");
  $("#main").innerHTML = `<h1>Insurance Plans</h1><p>${chips}</p><div class="grid">${cards}</div>
    <div class="card"><h3 style="margin-top:0">🧮 Premium calculator</h3>
      <form class="f" onsubmit="sub(event, calc)"><label>Plan<select name="plan_id">${options(PLANS.filter(p => p.active).map(p => [p.id, p.name]))}</select></label>
        <label>Sum insured (USD)<input name="sum_insured" type="number" min="1" value="1000000" required></label><label>Year built (ship)<input name="year_built" type="number" placeholder="2012"></label>
        <label><input type="checkbox" name="war_strikes" style="width:auto"> War &amp; strikes cover (+0.05%)</label><label><input type="checkbox" name="bbb" style="width:auto"> Build Back Better (+0.04%)</label>
        <button>Calculate</button></form><div id="quoteBox"></div>
      <small>Premium = sum insured x rate, plus loading for vessels 10+ years old and for earlier claims.</small></div>
    ${admin ? `<div class="card"><details><summary><b>+ Add a plan</b></summary><form class="f" onsubmit="sub(event, addPlan)"><label>Name<input name="name" required></label>
      <label>Category<select name="category">${options(["Hull", "Cargo", "Liability", "Builders", "Inland"])}</select></label><label>Rate % (0-10)<input name="rate" type="number" step="0.01" required></label>
      <label>Deductible (USD)<input name="deductible" type="number" required></label><label>Description<input name="description"></label><label>What it covers<input name="covers"></label><button>Add plan</button></form></details></div>` : ""}`;
}

// Show the premium breakdown returned by POST /api/quote
const calc = d => act(async () => {
  const r = await api("/api/quote", "POST", d);
  $("#quoteBox").innerHTML = `<div class="note"><b>${esc(r.plan)}</b><br>Rate: ${r.rate}% &nbsp; Base premium: ${money(r.base)}<br>Ship age ${r.age} years: +${r.age_load * 100}% &nbsp; Earlier claims (${r.claims_count}): +${r.claims_load * 100}%<br>
    <span class="big" style="font-size:24px">Premium ${money(r.premium)}</span> &nbsp; Deductible ${money(r.deductible)}</div>`;
});

// Admin: add / change a plan
const addPlan = d => act(async () => { await api("/api/plans", "POST", d); location.reload(); }, "Plan added");
const editPlan = id => { const p = PLANS.find(x => x.id === id); const rate = prompt("New rate in % of sum insured", p.rate); if (rate === null) return;
  const deductible = prompt("New deductible (USD)", p.deductible); if (deductible === null) return;
  act(async () => { await api("/api/plans/" + id, "PUT", { rate, deductible }); location.reload(); }, "Plan updated"); };
const togglePlan = id => { const p = PLANS.find(x => x.id === id); act(async () => { await api("/api/plans/" + id, "PUT", { active: p.active ? 0 : 1 }); location.reload(); }); };
