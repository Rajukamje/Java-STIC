/* pages/invoices.js - Invoices: totals, list, pay (demo: no card data is collected), PDF */

let INVS = [];

async function initPage() {
  INVS = await api("/api/invoices");
  const sum = f => INVS.filter(f).reduce((a, i) => a + i.amount, 0);
  $("#main").innerHTML = `<h1>Invoices</h1><div class="grid">
    <div class="card stat-card"><div class="ico">🧾</div><div>Billed<div class="big">${money(sum(() => true))}</div></div></div>
    <div class="card stat-card"><div class="ico">✅</div><div>Paid<div class="big">${money(sum(i => i.status === "Paid"))}</div></div></div>
    <div class="card stat-card"><div class="ico">⏳</div><div>Outstanding<div class="big">${money(sum(i => i.status !== "Paid"))}</div></div></div></div>
    <div class="card">` + table(["Invoice", "Policy", "Client", "Description", "Amount", "Issued", "Due", "Status", ""], INVS, i => `<tr><td>${i.invoice_number}</td><td>${i.policy_number}</td><td>${esc(i.client)}</td><td>${esc(i.description)}</td>
      <td>${money(i.amount)}</td><td>${i.issue_date}</td><td>${i.due_date}</td><td>${badge(i.status)}${i.paid_at ? `<br><small>${i.paid_at.slice(0, 10)} (${esc(i.method)})</small>` : ""}</td>
      <td>${i.status !== "Paid" ? `<button class="sm" onclick="payDialog(${i.id})">Pay</button>` : ""}<a class="btn pill sm" target="_blank" href="/api/invoices/${i.id}/pdf">PDF</a></td></tr>`) + `</div>`;
}

// Pay dialog: the method is only a label (demo). Never type real card numbers in a demo.
function payDialog(id) {
  const i = INVS.find(x => x.id === id);
  $("#dlg").innerHTML = `<h2>Pay ${i.invoice_number}</h2><p>Amount: <b>${money(i.amount)}</b></p><form class="f" style="grid-template-columns:1fr" onsubmit="sub(event, d => pay(${id}, d))">
    <label>Payment method<select name="method">${options(["Bank transfer", "Card", "Cheque"])}</select></label><small>Demo: no card or bank data is collected.</small><button>Confirm payment</button>
    <button type="button" class="alt" onclick="$('#dlg').close()">Close</button></form>`;
  $("#dlg").showModal();
}
const pay = (id, d) => act(async () => { await api(`/api/invoices/${id}/pay`, "POST", d); location.reload(); }, "Payment recorded");
