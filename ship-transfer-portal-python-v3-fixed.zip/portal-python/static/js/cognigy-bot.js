/* cognigy-bot.js - opens the Cognigy.AI chatbot (Insurance Risk Guardian AI) on every page.
   What it does:
     1) asks the server which Cognigy endpoint to use          GET /api/chat/config   (value comes from portal/config.py)
     2) loads the Cognigy Webchat v3 script                    first  js/../vendor/webchat.js  (self-hosted, recommended), else GitHub
     3) starts the chat and sends the login ticket + role to the bot (as message DATA, read in Cognigy as input.data.portal)
        - the ticket comes from GET /api/chat/token and lets the bot read ONLY the data of the logged-in user
     4) if Cognigy cannot be reached, the old rule based help bubble (js/help-bot.js) is used instead
   Loaded on every page after api.js (see the <script> lines at the bottom of each HTML file). */
(function () {
  const SOURCES = ["vendor/webchat.js", "https://github.com/Cognigy/Webchat/releases/latest/download/webchat.js"];
  const TITLE = "Insurance Risk Guardian AI";
  const COLOR = "#003781";                  // Allianz blue
  const INIT_TEXT = "";                     // text of the silent "hello" that carries the login data. If your Webchat ignores empty text, use "hi".
  let chat = null;

  const loadScript = src => new Promise((ok, no) => { const s = document.createElement("script"); s.src = src; s.onload = ok; s.onerror = () => no(new Error("cannot load " + src)); document.head.appendChild(s); });
  async function loadWebchat() {
    for (const src of SOURCES) { try { await loadScript(src); if (typeof initWebchat === "function") return src; } catch (e) { /* try the next source */ } }
    throw new Error("Cognigy webchat.js could not be loaded");
  }
  const getJson = async url => { const r = await fetch(url, { credentials: "same-origin" }); if (!r.ok) throw new Error(url + " " + r.status); return r.json(); };

  // old built-in bubble (rule based answers from /api/help)
  function fallback(why) { console.warn("Cognigy chat not used:", why); window.shipBotMode = "fallback"; loadScript("js/help-bot.js").catch(() => {}); }

  async function start() {
    let cfg, tok;
    try { cfg = await getJson("/api/chat/config"); tok = await getJson("/api/chat/token"); } catch (e) { return fallback(e.message); }
    if (!cfg.enabled) return fallback("disabled in config");
    try { await loadWebchat(); } catch (e) { return fallback(e.message); }
    try {
      const opts = { settings: { layout: { title: TITLE }, colors: { primaryColor: COLOR } } };
      if (tok.token && tok.id) opts.userId = "portal-user-" + tok.id;           // stable id for a logged-in user
      chat = await Promise.race([initWebchat(cfg.endpoint, opts), new Promise((_, no) => setTimeout(() => no(new Error("Cognigy endpoint did not answer in 12 s")), 12000))]);
    } catch (e) { return fallback(e.message); }
    window.shipBot = chat; window.shipBotMode = "cognigy";
    // Silent message with the login data. Cognigy reads it as input.data.portal (see COGNIGY_SETUP.md, step 3).
    const portal = { init: true, role: tok.role, name: tok.name, token: tok.token, page: document.body.dataset.page || "" };
    try { chat.sendMessage(INIT_TEXT, { portal }); } catch (e) { console.warn("Could not send login data to the bot:", e); }
  }

  // called by layout.js when the user logs out: forget the conversation of this browser (shared computers)
  window.shipBotReset = function () {
    try { if (chat) ["clearSessionHistory", "clearHistory"].forEach(m => typeof chat[m] === "function" && chat[m]()); } catch (e) {}
    try { [localStorage, sessionStorage].forEach(st => Object.keys(st).filter(k => /cognigy|webchat/i.test(k)).forEach(k => st.removeItem(k))); } catch (e) {}
  };

  start();
})();
