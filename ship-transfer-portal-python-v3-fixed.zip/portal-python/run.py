"""Start the website:  python run.py   ->  http://localhost:5000
If port 5000 is blocked or busy (Windows error 10013), the next free port is used and printed.
Optional settings:  PORT=8080 (first port to try)   HOST=0.0.0.0 (allow other computers; default is this computer only)"""
import os, socket
from portal import create_app

app = create_app()


def free_port(host, first):
    """First port from 'first' upwards that this computer lets us open."""
    for port in range(first, first + 50):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            s.bind((host, port))
            return port
        except OSError:                      # 10013 = blocked / reserved by Windows, 10048 = already in use
            continue
        finally:
            s.close()
    raise SystemExit("No free port found. Close other programs or run:  set PORT=8080  then  python run.py")


if __name__ == "__main__":
    host = os.environ.get("HOST", "127.0.0.1")
    port = free_port(host, int(os.environ.get("PORT", 5000)))
    print(f"\n  ShipTransfer Portal is running:  http://localhost:{port}\n  (press CTRL+C to stop)\n")
    app.run(host=host, port=port, debug=False)
