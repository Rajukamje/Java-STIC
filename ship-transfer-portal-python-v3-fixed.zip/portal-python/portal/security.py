"""security.py - protection for the whole site:
secure login cookie, CSRF token on every change request, security headers, rate limit on login/register, upload size limit."""
import os, time, secrets
from .config import cognigy_hosts, COGNIGY_ENABLED
from datetime import timedelta
from flask import request, session, jsonify

LIMITED = {"/api/login": 15, "/api/register": 10, "/api/forgot": 8, "/api/reset": 10}   # max POST requests per minute per IP


def init_security(app):
    app.config.update(
        SESSION_COOKIE_HTTPONLY=True,                       # JavaScript cannot read the login cookie
        SESSION_COOKIE_SAMESITE="Lax",                      # the cookie is not sent from other websites
        SESSION_COOKIE_SECURE=os.environ.get("HTTPS") == "1",   # set HTTPS=1 when the site runs on https
        PERMANENT_SESSION_LIFETIME=timedelta(hours=8),      # auto logout after 8 hours
        MAX_CONTENT_LENGTH=8 * 1024 * 1024)                 # uploads: 8 MB maximum
    hits = {}

    @app.before_request
    def guard():
        if not request.path.startswith("/api/"): return None
        if request.path.startswith("/api/bot/"): return None   # chatbot API: called by Cognigy with X-BOT-KEY + chat token, never with the login cookie (routes/cognigy.py)
        if request.method in ("POST", "PUT", "DELETE"):      # CSRF: every change must carry the token given by /api/me
            token = session.get("csrf")
            if not token or not secrets.compare_digest(token, request.headers.get("X-CSRF-Token", "")):
                return jsonify(error="Security check failed. Please reload the page."), 403
        limit = LIMITED.get(request.path)
        if limit and request.method == "POST" and not app.config.get("TESTING"):   # brute-force protection
            key, now = (request.remote_addr, request.path), time.time()
            recent = [t for t in hits.get(key, []) if now - t < 60]
            if len(recent) >= limit: return jsonify(error="Too many attempts. Please wait a minute."), 429
            hits[key] = recent + [now]

    @app.after_request
    def headers(resp):
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["X-Frame-Options"] = "SAMEORIGIN"
        resp.headers["Referrer-Policy"] = "same-origin"
        # Cognigy webchat: its script comes from our own /vendor/webchat.js (recommended) or from GitHub releases, and it talks to *.cognigy.cloud (https + websocket)
        bot = cognigy_hosts() if COGNIGY_ENABLED else ""
        gh = "https://github.com https://*.githubusercontent.com" if COGNIGY_ENABLED else ""
        resp.headers["Content-Security-Policy"] = (f"default-src 'self'; script-src 'self' 'unsafe-inline' {gh}; style-src 'self' 'unsafe-inline'; "
                                                   f"img-src 'self' data: blob: https:; font-src 'self' data:; connect-src 'self' {bot}; frame-src 'self' {bot}; "
                                                   "media-src 'self' blob: https:; object-src 'none'; frame-ancestors 'self'; form-action 'self'; base-uri 'self'")
        if os.environ.get("HTTPS") == "1": resp.headers["Strict-Transport-Security"] = "max-age=31536000"
        if request.path.startswith("/api/"): resp.headers["Cache-Control"] = "no-store"
        return resp

    @app.errorhandler(413)
    def too_big(e): return jsonify(error="File too large (maximum 8 MB)"), 413
