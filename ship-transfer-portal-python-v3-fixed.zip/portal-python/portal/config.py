"""Settings. Change them here or with environment variables."""
import os, secrets
BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))      # project folder
DB = os.environ.get("PORTAL_DB") or os.path.join(BASE, "data", "portal.db")   # SQLite database file (PORTAL_DB lets the tests use a temporary one)
PDF_DIR = os.path.join(BASE, "data", "pdfs")                              # issued certificate PDFs
UP_DIR = os.path.join(BASE, "data", "uploads")                            # documents uploaded by clients / brokers
DEMO_MODE = os.environ.get("DEMO_MODE", "1") == "1"                       # 1 = show the password-reset link on screen (no email server)

def _secret():
    """Secret key that signs the login cookie: from SECRET_KEY, or created once and saved in data/secret.key."""
    if os.environ.get("SECRET_KEY"): return os.environ["SECRET_KEY"]
    path = os.path.join(BASE, "data", "secret.key"); os.makedirs(os.path.dirname(path), exist_ok=True)
    if not os.path.exists(path): open(path, "w").write(secrets.token_hex(32))
    return open(path).read().strip()
SECRET_KEY = _secret()


# ---------------------------------------------------------------------------------------------
#  Cognigy.AI chatbot (Insurance Risk Guardian AI).  Change here or with environment variables.
# ---------------------------------------------------------------------------------------------
# Webchat v3 "Config URL" from Cognigy: Deploy > Endpoints > your endpoint > Config URL (the one used in initWebchat("...")).
COGNIGY_ENDPOINT_URL = os.environ.get("COGNIGY_ENDPOINT_URL",
    "https://endpoint-eu-dev-cai.cognigy.cloud/8e417498d9608f45d34a32b3282fa98f641e8d9b2393e5d70af8094f70b5b575")
WEBCHAT_URL = os.environ.get("WEBCHAT_URL", "https://github.com/Cognigy/Webchat/releases/latest/download/webchat.js")   # where the server downloads webchat.js from (once)
COGNIGY_ENABLED = os.environ.get("COGNIGY_ENABLED", "1") == "1"      # 0 = use the built-in rule based help bubble only
COGNIGY_TOKEN_TTL = int(os.environ.get("COGNIGY_TOKEN_TTL", 2 * 3600))   # chat login token lifetime in seconds (default 2 hours)


def _bot_key():
    """Secret that Cognigy sends in the X-BOT-KEY header: from COGNIGY_API_KEY, or created once and saved in data/bot.key."""
    if os.environ.get("COGNIGY_API_KEY"): return os.environ["COGNIGY_API_KEY"]
    path = os.path.join(BASE, "data", "bot.key"); os.makedirs(os.path.dirname(path), exist_ok=True)
    if not os.path.exists(path): open(path, "w").write(secrets.token_urlsafe(32))
    return open(path).read().strip()
COGNIGY_API_KEY = _bot_key()


def cognigy_hosts():
    """Hosts the browser must be allowed to talk to (used for the Content-Security-Policy)."""
    from urllib.parse import urlparse
    host = urlparse(COGNIGY_ENDPOINT_URL).hostname or ""
    root = ".".join(host.split(".")[-2:]) if host else "cognigy.cloud"      # cognigy.cloud
    return f"https://*.{root} wss://*.{root}"
