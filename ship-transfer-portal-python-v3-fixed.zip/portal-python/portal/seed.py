"""seed.py - creates the database tables, upgrades older databases, and adds demo data (users, plans, a policy ...)."""
from .core import *

SCHEMA_FILE = os.path.join(os.path.dirname(__file__), "schema.sql")

# Columns added after the first version: (table, column, definition). Older databases are upgraded automatically.
MIGRATIONS = [("policies", "plan_id", "INTEGER"), ("policies", "sum_insured", "REAL"), ("policies", "war_strikes", "INTEGER DEFAULT 0"),
              ("policies", "bbb", "INTEGER DEFAULT 0"), ("policies", "renewed_from", "INTEGER"), ("ships", "year_built", "INTEGER"),
              ("clients", "reg_no", "TEXT DEFAULT ''"), ("clients", "country", "TEXT DEFAULT ''"), ("clients", "contact_person", "TEXT DEFAULT ''"),
              ("clients", "kyc_status", "TEXT DEFAULT 'Pending'"), ("clients", "notes", "TEXT DEFAULT ''"),
              ("certificates", "renewed_from", "INTEGER"), ("notifications", "ref", "TEXT")]

# Insurance plans (idea: the product families of Allianz Commercial marine + cargo clauses ICC A / B / C)
PLANS = [('Hull & Machinery - Transit (Ship Transfer)', 'Hull', 'Delivery or transfer voyage of a vessel from port A to port B, self-propelled or towed.', 'Total and partial loss of hull and machinery on the declared route; collision, grounding, fire, heavy weather; salvage and general average. Subject to the Institute Time Clauses Hulls.', 0.39, 50000), ('Hull & Machinery - Annual Cover', 'Hull', 'Full-year cover for blue-water and brown-water vessels, single ships or fleets.', 'Hull, machinery and equipment for a full year; collision liability; sue and labour. Class must be maintained.', 0.55, 75000), ('Cargo ICC (A) - All Risks', 'Cargo', 'Widest cargo cover for goods in transit by sea, air, road and rail, including incidental storage.', 'All risks of physical loss or damage unless excluded (war, delay, inherent vice). Includes theft and pilferage.', 0.56, 5000), ('Cargo ICC (B) - Named Perils', 'Cargo', 'Mid-range cargo cover for stable goods on familiar routes.', 'Named perils only: fire, explosion, stranding, sinking, collision, overturning, earthquake, water damage, total loss overboard.', 0.32, 5000), ('Cargo ICC (C) - Basic Cover', 'Cargo', 'Lowest-cost cargo cover for low-value or low-risk goods.', 'Limited major perils: fire, explosion, stranding, sinking, collision, general average sacrifice.', 0.18, 2500), ('Marine Liability', 'Liability', 'Third-party liability for ship owners and operators, including marine property.', 'Damage to other vessels, ports and property; pollution response; crew injury; legal costs.', 0.25, 25000), ("Builder's Risk", 'Builders', 'Cover for a vessel while it is being built, converted or repaired in a yard.', 'Materials, equipment and vessel under construction; launching; sea trials.', 0.45, 50000), ('Inland Marine - Transit by Road / Rail', 'Inland', 'Moving or movable property transported over land (trucks, trains, barges).', 'Damage during loading, transport and unloading; theft; accident; weather.', 0.2, 2500)]


def add_user(c, name, email, pw, role, company):
    return c.execute("INSERT INTO users(name,email,phone,password,role,company,address) VALUES(?,?,?,?,?,?,?)",
                     (name, email, "+65 6000 0000", gph(pw), role, company, "18 Harbour Road, Singapore 049315")).lastrowid


def init_db():
    os.makedirs(PDF_DIR, exist_ok=True); os.makedirs(UP_DIR, exist_ok=True)
    c = sqlite3.connect(DB)
    with open(SCHEMA_FILE, encoding="utf-8") as f: c.executescript(f.read())
    for table, col, ddl in MIGRATIONS:                       # upgrade older databases
        if col not in [r[1] for r in c.execute(f"PRAGMA table_info({table})")]: c.execute(f"ALTER TABLE {table} ADD COLUMN {col} {ddl}")
    if not c.execute("SELECT 1 FROM plans").fetchone():
        c.executemany("INSERT INTO plans(name,category,description,covers,rate,deductible) VALUES(?,?,?,?,?,?)", PLANS)
    if not c.execute("SELECT 1 FROM users").fetchone():      # demo data only for an empty database
        add_user(c, "Admin User", "admin@portal.com", "Admin@123", "admin", "Portal Admin")
        brokers = []
        for name, email, co, cat in [("Ben Broker", "broker@portal.com", "Oceanic Marine Brokers Ltd.", "Marine"), ("Maria Cargo", "maria@portal.com", "Harbor Risk Partners", "Cargo"), ("Tom Tide", "tom@portal.com", "BlueWave Brokers", "Hull")]:
            uid = add_user(c, name, email, "Broker@123", "broker", co); brokers.append(c.execute("INSERT INTO brokers(user_id,category) VALUES(?,?)", (uid, cat)).lastrowid)
        cu = add_user(c, "Chris Client", "client@portal.com", "Client@123", "client", "Northwind Shipping Pte. Ltd.")
        cid = c.execute("INSERT INTO clients(user_id,broker_id,reg_no,country,contact_person) VALUES(?,?,'201912345K','Singapore','Chris Client')", (cu, brokers[0])).lastrowid
        sid = c.execute("INSERT INTO ships(name,imo,flag,type,tonnage,year_built,owner_client_id) VALUES('MV Sea Horizon','9074729','Panama','General cargo',18450,2012,?)", (cid,)).lastrowid
        pid = c.execute("INSERT INTO policies(policy_number,client_id,broker_id,ship_id,type,premium,start_date,end_date,plan_id,sum_insured) VALUES('MTP-2026-000001',?,?,?,?,?,?,?,1,12500000)",
                        (cid, brokers[0], sid, PLANS[0][0], 48750.0, (today() - dt.timedelta(60)).isoformat(), (today() + dt.timedelta(300)).isoformat())).lastrowid
        c.execute("INSERT INTO certificates(policy_id,from_location,to_location,valid_from,valid_to,mode,sum_insured,status,created_at) VALUES(?,?,?,?,?,?,?,'Submitted',?)",
                  (pid, "Singapore", "Rotterdam, NL", (today() + dt.timedelta(3)).isoformat(), (today() + dt.timedelta(36)).isoformat(), "Self-propelled, with cargo on board", 12500000.0, now()))
        c.execute("INSERT INTO invoices(invoice_number,policy_id,client_id,description,amount,issue_date,due_date) VALUES('INV-2026-000001',?,?,'Premium for policy MTP-2026-000001',48750,?,?)",
                  (pid, cid, today().isoformat(), (today() + dt.timedelta(14)).isoformat()))
        # demo reviews from other (fictional) clients so the broker directory is not empty
        for i, (b, rating, text) in enumerate([(0, 5, "Fast and clear. Our transfer certificate was ready in one day."), (0, 4, "Good advice on the right hull plan."), (1, 5, "Handled our cargo claim without any stress."), (2, 4, "Knows hull risks very well.")]):
            u2 = add_user(c, f"Demo Client {i + 1}", f"demo{i + 1}@portal.com", "Client@123", "client", ["Atlas Lines", "Blue Harbour Ltd.", "Orient Freight", "Nordic Tankers"][i])
            c2 = c.execute("INSERT INTO clients(user_id,broker_id) VALUES(?,?)", (u2, brokers[b])).lastrowid
            c.execute("INSERT INTO reviews(broker_id,client_id,rating,comment,created_at) VALUES(?,?,?,?,?)", (brokers[b], c2, rating, text, now()))
        c.execute("INSERT INTO reviews(broker_id,client_id,rating,comment,created_at) SELECT ?,?,?,?,? WHERE 0", (0, 0, 0, "", ""))
    c.commit(); c.close()
