"""core.py - shared helpers used by every module:
database access, who is logged in, role checks (enforced on the server), data scope, audit log, validation, statuses."""
import os, re, io, csv, sqlite3, secrets, datetime as dt
from collections import Counter, defaultdict
from functools import wraps
from flask import request, session, jsonify, send_file, g
from werkzeug.security import generate_password_hash as gph, check_password_hash as cph
from .config import DB, PDF_DIR, UP_DIR, BASE, SECRET_KEY, DEMO_MODE

def now(): return dt.datetime.now().isoformat(timespec="seconds")
def today(): return dt.date.today()
def bad(msg, code=400): return jsonify(error=msg), code

def conn():
    if "db" not in g:
        g.db = sqlite3.connect(DB); g.db.row_factory = sqlite3.Row
    return g.db

def close_db(_):
    d = g.pop("db", None)
    if d: d.close()

def q(sql, args=(), one=False):
    rows = [dict(r) for r in conn().execute(sql, args).fetchall()]
    return (rows[0] if rows else None) if one else rows

def run(sql, args=()):
    cur = conn().execute(sql, args); conn().commit(); return cur.lastrowid

def audit(action, target="", uid=None):
    """Write the audit log. uid is given by the chatbot API (no login cookie there); websites use the logged-in user."""
    if uid is None:
        u = current(); uid = u["id"] if u else None
    run("INSERT INTO audit(user_id,action,target,time) VALUES(?,?,?,?)", (uid, action, target, now()))

def notify(user_id, kind, detail):  # e-mails are logged here (and sent if SMTP_HOST is set)
    run("INSERT INTO notifications(user_id,type,detail,sent_at) VALUES(?,?,?,?)", (user_id, kind, detail, now()))

def current():
    uid = session.get("uid")
    return q("SELECT * FROM users WHERE id=?", (uid,), one=True) if uid else None

def need(*roles):
    def deco(f):
        @wraps(f)
        def w(*a, **k):
            u = current()
            if not u: return bad("Please log in", 401)
            if roles and u["role"] not in roles: return bad("Access denied for your role", 403)  # enforced on the server
            return f(*a, **k)
        return w
    return deco

def ids(u):
    c = q("SELECT id FROM clients WHERE user_id=?", (u["id"],), one=True)
    b = q("SELECT id FROM brokers WHERE user_id=?", (u["id"],), one=True)
    return (c["id"] if c else None), (b["id"] if b else None)

def scope(u, a="p"):
    """SQL fragment limiting policies to what this role may see."""
    cid, bid = ids(u)
    if u["role"] == "admin": return "1=1", ()
    if u["role"] == "broker": return f"{a}.broker_id=?", (bid,)
    return f"{a}.client_id=?", (cid,)

def pstatus(p):
    if p["status"] == "Cancelled": return "Cancelled"
    if p["end_date"] < today().isoformat(): return "Expired"
    if p["end_date"] <= (today() + dt.timedelta(30)).isoformat(): return "Expiring Soon"
    return "Active"

def cstatus(c):
    if c["status"] == "Issued" and c["valid_to"] < today().isoformat(): return "Expired"
    return c["status"]

def pdate(s):
    try: return dt.date.fromisoformat(s)
    except Exception: return None

EMAIL = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
PHONE = re.compile(r"^\+?[0-9 \-]{7,15}$")
def strong(p):
    return len(p) >= 8 and re.search("[a-z]", p) and re.search("[A-Z]", p) and re.search(r"\d", p) and re.search(r"[^\w\s]", p)
PW_MSG = "Password needs 8+ characters with upper case, lower case, number and symbol"

POL_SQL = """SELECT p.*, s.name ship_name, s.imo, COALESCE(NULLIF(cu.company,''),cu.name) client,
 COALESCE(NULLIF(bu.company,''),bu.name,'Unassigned') broker
 FROM policies p JOIN ships s ON s.id=p.ship_id JOIN clients cl ON cl.id=p.client_id JOIN users cu ON cu.id=cl.user_id
 LEFT JOIN brokers b ON b.id=p.broker_id LEFT JOIN users bu ON bu.id=b.user_id """
CERT_SQL = """SELECT c.*, p.policy_number, p.type cover, p.premium, p.status pstat, p.end_date, s.name ship_name, s.imo, s.flag,
 s.type ship_type, s.tonnage, COALESCE(NULLIF(cu.company,''),cu.name) insured, cu.address,
 COALESCE(NULLIF(bu.company,''),bu.name,'Direct') broker
 FROM certificates c JOIN policies p ON p.id=c.policy_id JOIN ships s ON s.id=p.ship_id JOIN clients cl ON cl.id=p.client_id
 JOIN users cu ON cu.id=cl.user_id LEFT JOIN brokers b ON b.id=p.broker_id LEFT JOIN users bu ON bu.id=b.user_id """

def cert_list(u, where="", args=()):
    sc, sa = scope(u)
    rows = q(CERT_SQL + f" WHERE {sc} {where} ORDER BY c.id DESC", sa + args)
    for c in rows: c["status"] = cstatus(c)
    return rows



# =====================================================================
#  Insurance process helpers: plans/quotes, invoices, notifications, documents
# =====================================================================
CLAIM_TYPES = ["Collision", "Grounding", "Fire / Explosion", "Heavy weather damage", "Machinery breakdown", "Cargo damage", "Cargo theft", "Total loss", "Liability / third party", "Other"]
DOC_TYPES = ["ID / Company registration", "Ship registry certificate", "Class certificate", "Survey report",
             "Cargo manifest / Bill of lading", "Commercial invoice", "Claim evidence (photos / report)", "Other"]
REQUIRED_DOCS = DOC_TYPES[:4]          # documents a broker must collect before the client is "KYC Verified"


def istatus(i):
    """Invoice status: Paid / Overdue (unpaid after due date) / Unpaid."""
    if i["status"] == "Paid": return "Paid"
    return "Overdue" if i["due_date"] < today().isoformat() else "Unpaid"


def client_ok(u, cid):
    """May this user work with this client? Admin: any. Broker: assigned clients. Client: only himself."""
    if u["role"] == "admin": return True
    cl = q("SELECT * FROM clients WHERE id=?", (cid,), one=True)
    if not cl: return False
    c, b = ids(u)
    return (u["role"] == "client" and cl["id"] == c) or (u["role"] == "broker" and b is not None and cl["broker_id"] == b)


def push(user_id, kind, detail, ref=None):
    """Save a notification (= email log). 'ref' makes it unique, so the same reminder is never sent twice."""
    if not user_id: return
    if ref and q("SELECT 1 FROM notifications WHERE user_id=? AND ref=?", (user_id, ref), one=True): return
    run("INSERT INTO notifications(user_id,type,detail,sent_at,ref) VALUES(?,?,?,?,?)", (user_id, kind, detail, now(), ref))


def parties(policy_id):
    """User ids of the client and the broker of a policy."""
    r = q("SELECT cl.user_id cu, b.user_id bu FROM policies p JOIN clients cl ON cl.id=p.client_id LEFT JOIN brokers b ON b.id=p.broker_id WHERE p.id=?", (policy_id,), one=True)
    return [x for x in (r["cu"], r["bu"]) if x] if r else []


def quote(plan, sum_insured, year_built=0, war=0, bbb=0, client_id=None):
    """Premium calculation (basic underwriting, like the risk factors Allianz lists: vessel age and loss history).
    rate % of the sum insured  + add-ons (war & strikes, Build Back Better)  + loading for old vessels  + loading for earlier claims."""
    rate = plan["rate"] + (0.05 if war else 0) + (0.04 if bbb else 0)
    base = sum_insured * rate / 100
    age = today().year - year_built if year_built else 0
    age_load = 0.15 if age >= 20 else 0.07 if age >= 10 else 0.0
    n = q("SELECT COUNT(*) n FROM claims c JOIN policies p ON p.id=c.policy_id WHERE p.client_id=? AND c.status!='Rejected'", (client_id,), one=True)["n"] if client_id else 0
    claims_load = min(0.05 * n, 0.20)
    return {"rate": round(rate, 3), "base": round(base, 2), "age": age, "age_load": age_load, "claims_count": n, "claims_load": claims_load,
            "premium": round(base * (1 + age_load + claims_load), 2), "deductible": plan["deductible"]}


def create_invoice(policy_id, client_id, amount, description):
    """New unpaid invoice, due in 14 days."""
    iid = run("INSERT INTO invoices(policy_id,client_id,description,amount,issue_date,due_date,status) VALUES(?,?,?,?,?,?,'Unpaid')",
              (policy_id, client_id, description, amount, today().isoformat(), (today() + dt.timedelta(days=14)).isoformat()))
    run("UPDATE invoices SET invoice_number=? WHERE id=?", (f"INV-{today().year}-{iid:06d}", iid))
    return iid


def run_reminders():
    """Create notifications: policy / certificate expiring in 30, 15, 7 days, expired, and overdue invoices. Safe to run often (no duplicates)."""
    t = today()
    def level(end):
        left = (dt.date.fromisoformat(end) - t).days
        if -30 <= left < 0: return "expired", left
        if 0 <= left <= 30: return (7 if left <= 7 else 15 if left <= 15 else 30), left
        return None, left
    for p in q("SELECT * FROM policies WHERE status!='Cancelled'"):
        lvl, left = level(p["end_date"])
        if lvl: 
            msg = f"Policy {p['policy_number']} has expired. Renew it to stay covered." if lvl == "expired" else f"Policy {p['policy_number']} expires in {left} day(s). Renew it now."
            for uid in parties(p["id"]): push(uid, "reminder", msg, f"pol:{p['id']}:{lvl}")
    for c in q("SELECT * FROM certificates WHERE status='Issued'"):
        lvl, left = level(c["valid_to"])
        if lvl:
            msg = f"Certificate {c['certificate_number']} has expired. Request a renewal." if lvl == "expired" else f"Certificate {c['certificate_number']} expires in {left} day(s). Renew it now."
            for uid in parties(c["policy_id"]): push(uid, "reminder", msg, f"cert:{c['id']}:{lvl}")
    for i in q("SELECT * FROM invoices WHERE status!='Paid' AND due_date < ?", (t.isoformat(),)):
        for uid in parties(i["policy_id"]): push(uid, "invoice", f"Invoice {i['invoice_number']} is overdue (USD {i['amount']:,.0f}).", f"inv:{i['id']}:overdue")
