-- DATABASE: all tables of the portal (SQLite). Created automatically at startup.
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, name TEXT, email TEXT UNIQUE, phone TEXT, password TEXT, role TEXT,
  status TEXT DEFAULT 'Active', verified INTEGER DEFAULT 1, company TEXT DEFAULT '', address TEXT DEFAULT '', failed INTEGER DEFAULT 0, locked_until TEXT);
CREATE TABLE IF NOT EXISTS brokers(id INTEGER PRIMARY KEY, user_id INTEGER, category TEXT DEFAULT 'Marine', status TEXT DEFAULT 'Active', deleted_at TEXT);
CREATE TABLE IF NOT EXISTS clients(id INTEGER PRIMARY KEY, user_id INTEGER, broker_id INTEGER);
CREATE TABLE IF NOT EXISTS ships(id INTEGER PRIMARY KEY, name TEXT, imo TEXT, flag TEXT, type TEXT, tonnage INTEGER, owner_client_id INTEGER);
CREATE TABLE IF NOT EXISTS policies(id INTEGER PRIMARY KEY, policy_number TEXT, client_id INTEGER, broker_id INTEGER, ship_id INTEGER,
  type TEXT, premium REAL, start_date TEXT, end_date TEXT, status TEXT DEFAULT 'Active');
CREATE TABLE IF NOT EXISTS certificates(id INTEGER PRIMARY KEY, certificate_number TEXT, policy_id INTEGER, from_location TEXT, to_location TEXT,
  valid_from TEXT, valid_to TEXT, mode TEXT, sum_insured REAL, deductible REAL DEFAULT 50000, status TEXT DEFAULT 'Submitted',
  version INTEGER DEFAULT 1, pdf_path TEXT, issued_by TEXT, issued_at TEXT, created_at TEXT);
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY, user_id INTEGER, action TEXT, target TEXT, time TEXT);
CREATE TABLE IF NOT EXISTS notifications(id INTEGER PRIMARY KEY, user_id INTEGER, type TEXT, detail TEXT, sent_at TEXT);
-- Password reset links (valid 30 minutes)
CREATE TABLE IF NOT EXISTS password_resets(token TEXT PRIMARY KEY, user_id INTEGER, expires TEXT);

-- Insurance plans / products (cargo ICC A/B/C, hull, liability ...). rate = % of the sum insured
CREATE TABLE IF NOT EXISTS plans(id INTEGER PRIMARY KEY, name TEXT, category TEXT, description TEXT, covers TEXT, rate REAL, deductible REAL, active INTEGER DEFAULT 1);
-- Claims: Submitted -> Under Review -> Approved -> Paid (or Rejected)
CREATE TABLE IF NOT EXISTS claims(id INTEGER PRIMARY KEY, claim_number TEXT, policy_id INTEGER, incident_date TEXT, incident_type TEXT, description TEXT,
  amount_claimed REAL, amount_approved REAL, status TEXT DEFAULT 'Submitted', decision_note TEXT, created_by INTEGER, created_at TEXT, updated_at TEXT);
-- Invoices (premium bills)
CREATE TABLE IF NOT EXISTS invoices(id INTEGER PRIMARY KEY, invoice_number TEXT, policy_id INTEGER, client_id INTEGER, description TEXT, amount REAL,
  issue_date TEXT, due_date TEXT, status TEXT DEFAULT 'Unpaid', paid_at TEXT, method TEXT);
-- Broker reviews written by clients (one review per client and broker)
CREATE TABLE IF NOT EXISTS reviews(id INTEGER PRIMARY KEY, broker_id INTEGER, client_id INTEGER, rating INTEGER, comment TEXT, created_at TEXT, UNIQUE(broker_id, client_id));
-- Documents collected for the insurance process (files are stored in data/uploads)
CREATE TABLE IF NOT EXISTS documents(id INTEGER PRIMARY KEY, client_id INTEGER, policy_id INTEGER, claim_id INTEGER, doc_type TEXT, filename TEXT, stored_name TEXT,
  status TEXT DEFAULT 'Pending', note TEXT, uploaded_by INTEGER, uploaded_at TEXT);

-- Newsletter sign-ups (footer) and contact messages (contact page)
CREATE TABLE IF NOT EXISTS subscribers(id INTEGER PRIMARY KEY, email TEXT UNIQUE, created_at TEXT);
CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY, name TEXT, email TEXT, topic TEXT, message TEXT, created_at TEXT);
