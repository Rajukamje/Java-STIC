"""routes/claims.py - Claims: submit, list, admin review (Submitted -> Under Review -> Approved -> Paid, or Rejected)."""
from flask import Blueprint
from ..core import *

bp = Blueprint("claims", __name__)

CLAIM_SQL = """SELECT c.*, p.client_id, p.policy_number, p.sum_insured, s.name ship_name, COALESCE(NULLIF(cu.company,''),cu.name) client
 FROM claims c JOIN policies p ON p.id=c.policy_id JOIN ships s ON s.id=p.ship_id JOIN clients cl ON cl.id=p.client_id JOIN users cu ON cu.id=cl.user_id """

NEXT = {"Submitted": ["Under Review", "Rejected"], "Under Review": ["Approved", "Rejected"], "Approved": ["Paid"], "Rejected": [], "Paid": []}   # allowed status changes


# GET /api/claims : claims this role may see
@bp.get("/api/claims")
@need()
def claims():
    sc, sa = scope(current())
    rows = q(CLAIM_SQL + f"WHERE {sc} ORDER BY c.id DESC", sa)
    for r in rows: r["next"] = NEXT[r["status"]]
    return jsonify(dict(rows=rows, types=CLAIM_TYPES))


def submit_claim(u, d):
    """Check and save a claim for user u. Returns (answer dict, http status). Used by the website AND by the chatbot API (routes/cognigy.py),
    so both follow exactly the same rules."""
    sc, sa = scope(u)
    p = q(f"SELECT p.* FROM policies p WHERE p.id=? AND {sc}", (d.get("policy_id"),) + sa, one=True)
    if not p: return {"error": "Choose one of your policies"}, 400
    if p["status"] == "Cancelled": return {"error": "This policy is cancelled"}, 400
    inc = pdate(d.get("incident_date", ""))
    if not inc or inc > today(): return {"error": "Incident date must be today or earlier"}, 400
    if not (p["start_date"] <= inc.isoformat() <= p["end_date"]): return {"error": "The incident is outside the policy period"}, 400
    if d.get("incident_type") not in CLAIM_TYPES: return {"error": "Choose an incident type"}, 400
    if len(str(d.get("description", "")).strip()) < 10: return {"error": "Describe what happened (at least 10 characters)"}, 400
    try: amount = float(d.get("amount_claimed"))
    except (TypeError, ValueError): return {"error": "Amount claimed must be a number"}, 400
    if amount <= 0 or (p["sum_insured"] and amount > p["sum_insured"]): return {"error": "Amount must be above zero and not more than the sum insured"}, 400
    cid = run("INSERT INTO claims(policy_id,incident_date,incident_type,description,amount_claimed,status,created_by,created_at,updated_at) VALUES(?,?,?,?,?,'Submitted',?,?,?)",
              (p["id"], inc.isoformat(), d["incident_type"], str(d["description"]).strip()[:2000], amount, u["id"], now(), now()))
    num = f"CLM-{today().year}-{cid:06d}"; run("UPDATE claims SET claim_number=? WHERE id=?", (num, cid))
    for uid in parties(p["id"]) + [r["id"] for r in q("SELECT id FROM users WHERE role='admin'")]: push(uid, "claim", f"Claim {num} submitted for policy {p['policy_number']} (USD {amount:,.0f}).")
    audit("submit claim", num, u["id"]); return {"ok": True, "claim_number": num}, 200


# POST /api/claims : report a loss on one of my policies
@bp.post("/api/claims")
@need()
def add_claim():
    body, code = submit_claim(current(), request.json or {})
    return jsonify(body), code


# PUT /api/claims/<id> : admin moves the claim forward, sets the approved amount and a decision note
@bp.put("/api/claims/<int:cid>")
@need("admin")
def review_claim(cid):
    d = request.json or {}; c = q("SELECT c.*, p.policy_number FROM claims c JOIN policies p ON p.id=c.policy_id WHERE c.id=?", (cid,), one=True)
    if not c: return bad("Claim not found", 404)
    status = d.get("status")
    if status not in NEXT[c["status"]]: return bad(f"A {c['status']} claim cannot change to {status}")
    approved = c["amount_approved"]
    if status == "Approved":
        try: approved = float(d.get("amount_approved"))
        except (TypeError, ValueError): return bad("Enter the approved amount")
        if not (0 < approved <= c["amount_claimed"]): return bad("Approved amount must be above zero and not more than the amount claimed")
    note = str(d.get("decision_note", "")).strip()[:1000]
    if status == "Rejected" and not note: return bad("Please give a reason for the rejection")
    run("UPDATE claims SET status=?, amount_approved=?, decision_note=?, updated_at=? WHERE id=?", (status, approved, note or c["decision_note"], now(), cid))
    for uid in parties(c["policy_id"]): push(uid, "claim", f"Claim {c['claim_number']} is now: {status}." + (f" Approved USD {approved:,.0f}." if status in ("Approved", "Paid") else ""))
    audit("claim " + status.lower(), c["claim_number"]); return jsonify(ok=True)
