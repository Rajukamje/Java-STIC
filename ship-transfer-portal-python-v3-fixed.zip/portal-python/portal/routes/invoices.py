"""routes/invoices.py - Invoices: list, pay (demo, no card data is collected), PDF."""
from flask import Blueprint
from ..core import *
from ..pdf_service import make_invoice_pdf

bp = Blueprint("invoices", __name__)

INV_SQL = """SELECT i.*, p.policy_number, p.type plan, COALESCE(NULLIF(cu.company,''),cu.name) client, cu.address
 FROM invoices i JOIN policies p ON p.id=i.policy_id JOIN clients cl ON cl.id=i.client_id JOIN users cu ON cu.id=cl.user_id """


def rows_for(u, where="", args=()):
    sc, sa = scope(u)
    rows = q(INV_SQL + f"WHERE {sc} {where} ORDER BY i.id DESC", sa + args)
    for r in rows: r["status"] = istatus(r)
    return rows


# GET /api/invoices : invoices this role may see (status Paid / Unpaid / Overdue)
@bp.get("/api/invoices")
@need()
def invoices(): return jsonify(rows_for(current()))


# POST /api/invoices/<id>/pay : mark as paid. Demo only: the method is just a label, no card or bank data is stored.
@bp.post("/api/invoices/<int:iid>/pay")
@need()
def pay(iid):
    rows = rows_for(current(), "AND i.id=?", (iid,)); method = (request.json or {}).get("method")
    if not rows: return bad("Invoice not found", 404)
    if rows[0]["status"] == "Paid": return bad("Already paid")
    if method not in ("Bank transfer", "Card", "Cheque"): return bad("Choose a payment method")
    run("UPDATE invoices SET status='Paid', paid_at=?, method=? WHERE id=?", (now(), method, iid))
    for uid in parties(rows[0]["policy_id"]): push(uid, "invoice", f"Invoice {rows[0]['invoice_number']} was paid (USD {rows[0]['amount']:,.0f}). Thank you.")
    audit("pay invoice", rows[0]["invoice_number"]); return jsonify(ok=True)


# GET /api/invoices/<id>/pdf : invoice as PDF
@bp.get("/api/invoices/<int:iid>/pdf")
@need()
def invoice_pdf(iid):
    rows = rows_for(current(), "AND i.id=?", (iid,))
    if not rows: return bad("Invoice not found", 404)
    return send_file(io.BytesIO(make_invoice_pdf(rows[0])), mimetype="application/pdf", download_name=rows[0]["invoice_number"] + ".pdf")
