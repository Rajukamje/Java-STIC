"""routes/auth.py - Login module: register, login, logout, profile, change password."""
from flask import Blueprint
from ..core import *

bp = Blueprint("auth", __name__)

# POST /api/register : create a Client or Broker account
@bp.post("/api/register")
def register():
    d = request.json or {}
    name, email, phone, pw = (d.get(k, "").strip() for k in ("name", "email", "phone", "password"))
    if not name: return bad("Full name is required")
    if not EMAIL.match(email): return bad("Enter a valid email")
    if q("SELECT 1 FROM users WHERE email=?", (email.lower(),)): return bad("Email already registered")
    if not PHONE.match(phone): return bad("Enter a valid phone number")
    if not strong(pw): return bad(PW_MSG)
    if pw != d.get("confirm"): return bad("Passwords do not match")
    if d.get("role") not in ("client", "broker"): return bad("Role must be Client or Broker")  # admins are created by admins only
    uid = run("INSERT INTO users(name,email,phone,password,role,company) VALUES(?,?,?,?,?,?)",
              (name, email.lower(), phone, gph(pw), d["role"], d.get("company", "")))
    run("INSERT INTO clients(user_id) VALUES(?)" if d["role"] == "client" else "INSERT INTO brokers(user_id) VALUES(?)", (uid,))
    notify(uid, "verification", "Welcome! Email verification link (demo: account is auto-verified).")
    return jsonify(ok=True)

# POST /api/login : login (type must match role; 5 wrong tries lock 15 min)
@bp.post("/api/login")
def login():
    d = request.json or {}
    u = q("SELECT * FROM users WHERE email=?", (d.get("email", "").strip().lower(),), one=True)
    if u and u["locked_until"] and u["locked_until"] > now(): return bad("Account locked for 15 minutes after 5 failed attempts", 423)
    if not u or not cph(u["password"], d.get("password", "")):
        if u:
            f = u["failed"] + 1
            run("UPDATE users SET failed=?, locked_until=? WHERE id=?",
                (0 if f >= 5 else f, (dt.datetime.now() + dt.timedelta(minutes=15)).isoformat(timespec="seconds") if f >= 5 else None, u["id"]))
        return bad("Wrong email or password", 401)
    if u["role"] != d.get("role"): return bad("Login type does not match your account role", 403)
    if u["status"] != "Active": return bad("Account is inactive", 403)
    run("UPDATE users SET failed=0, locked_until=NULL WHERE id=?", (u["id"],))
    session.clear(); session["uid"] = u["id"]; session["csrf"] = secrets.token_hex(16); session.permanent = True; audit("login")   # new session at login (prevents session fixation)
    return jsonify(user=public(u))

def public(u): return {k: u[k] for k in ("id", "name", "email", "phone", "role", "company", "address")}

# POST /api/logout : end the session
@bp.post("/api/logout")
def logout():
    audit("logout"); session.clear(); return jsonify(ok=True)

# GET /api/me : who is logged in?
@bp.get("/api/me")
def me():
    u = current()
    session.permanent = True; session.setdefault("csrf", secrets.token_hex(16))   # CSRF token for every visitor; the browser sends it back in a header
    return jsonify(user=public(u) if u else None, csrf=session["csrf"])

# PUT /api/profile : edit own profile
@bp.put("/api/profile")
@need()
def profile():
    d = request.json or {}; u = current()
    if d.get("phone") and not PHONE.match(d["phone"]): return bad("Enter a valid phone number")
    run("UPDATE users SET name=?, phone=?, address=?, company=? WHERE id=?",
        (d.get("name") or u["name"], d.get("phone") or u["phone"], d.get("address", ""), d.get("company", ""), u["id"]))
    audit("edit profile"); return jsonify(ok=True)  # email and role cannot be edited

# POST /api/password : change own password
@bp.post("/api/password")
@need()
def password():
    d = request.json or {}; u = current()
    if not cph(u["password"], d.get("old", "")): return bad("Old password is wrong")
    if not strong(d.get("new", "")): return bad(PW_MSG)
    if d["new"] != d.get("confirm"): return bad("Passwords do not match")
    run("UPDATE users SET password=? WHERE id=?", (gph(d["new"]), u["id"])); audit("change password")
    return jsonify(ok=True)
