"""routes/dashboard.py - Dashboard: number cards and chart data (pie, column, line) for each role."""
from flask import Blueprint
from ..core import *
from .certificates import cert_list

bp = Blueprint("dashboard", __name__)


# GET /api/dashboard : cards + chart data for the logged-in role
@bp.get("/api/dashboard")
@need()
def dashboard():
    run_reminders(); u = current(); sc, sa = scope(u); role = u["role"]
    pols = q(f"SELECT p.* FROM policies p WHERE {sc}", sa)
    certs = cert_list(u)
    claims = q(f"SELECT c.* FROM claims c JOIN policies p ON p.id=c.policy_id WHERE {sc}", sa)
    invs = q(f"SELECT i.* FROM invoices i JOIN policies p ON p.id=i.policy_id WHERE {sc}", sa)
    for i in invs: i["status"] = istatus(i)
    cards = {"Policies": len(pols), "Certificates": len(certs), "Pending approval": sum(c["status"] == "Submitted" for c in certs),
             "Open claims": sum(c["status"] in ("Submitted", "Under Review") for c in claims),
             "Outstanding invoices (USD)": round(sum(i["amount"] for i in invs if i["status"] != "Paid"))}
    if role == "admin":
        cards["Clients"] = q("SELECT COUNT(*) n FROM clients", one=True)["n"]; cards["Brokers"] = q("SELECT COUNT(*) n FROM brokers WHERE deleted_at IS NULL", one=True)["n"]
        cards["Documents to verify"] = q("SELECT COUNT(*) n FROM documents WHERE status='Pending'", one=True)["n"]
    elif role == "broker":
        b = ids(u)[1]; cards["Clients"] = q("SELECT COUNT(*) n FROM clients WHERE broker_id=?", (b,), one=True)["n"]
        cards["Documents to verify"] = q("SELECT COUNT(*) n FROM documents d JOIN clients c ON c.id=d.client_id WHERE d.status='Pending' AND c.broker_id=?", (b,), one=True)["n"]
    else:
        docs = q("SELECT doc_type, status FROM documents WHERE client_id=?", (ids(u)[0],))
        cards["Documents missing"] = sum(not any(d["doc_type"] == t and d["status"] != "Rejected" for d in docs) for t in REQUIRED_DOCS)
    prem = defaultdict(float)
    for p in pols: prem[p["start_date"][:7]] += p["premium"]
    out = {"cards": cards,
           "Policies by status": dict(Counter(pstatus(p) for p in pols)),
           "Claims by status": dict(Counter(c["status"] for c in claims)),
           "Invoices by status": dict(Counter(i["status"] for i in invs)),
           "Premium by month (USD)": dict(sorted(prem.items())),
           "Claims vs premium (USD)": {"Premium": round(sum(p["premium"] for p in pols)), "Claimed": round(sum(c["amount_claimed"] for c in claims)),
                                       "Approved": round(sum(c["amount_approved"] or 0 for c in claims if c["status"] in ("Approved", "Paid")))},
           "Certificates per month": dict(sorted(Counter((c["issued_at"] or c["created_at"])[:7] for c in certs).items())),
           "Policies by plan": dict(Counter(p["type"] for p in pols))}
    if role == "admin":
        top = defaultdict(float)
        for p in q(POL_SQL): top[p["broker"]] += p["premium"]
        out["Top brokers by premium"] = dict(sorted(top.items(), key=lambda x: -x[1])[:5])
    out["Expiring soon"] = ([f"Policy {p['policy_number']} ends {p['end_date']}" for p in pols if pstatus(p) == "Expiring Soon"] +
                            [f"Certificate {c['certificate_number']} ends {c['valid_to']}" for c in certs if c["status"] == "Issued" and c["valid_to"] <= (today() + dt.timedelta(30)).isoformat()])
    return jsonify(out)
