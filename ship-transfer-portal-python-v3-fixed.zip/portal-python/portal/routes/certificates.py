"""routes/certificates.py - Certificates module: request, approve + issue (PDF + QR), cancel, download, email, public verify."""
from flask import Blueprint
from ..core import *
from ..pdf_service import make_pdf, send_mail

bp = Blueprint("certificates", __name__)

# GET /api/certificates : certificates this role may see
@bp.get("/api/certificates")
@need()
def certificates(): return jsonify(cert_list(current()))

# POST /api/certificates : request a certificate (Submitted)
@bp.post("/api/certificates")
@need()
def request_cert():
    d = request.json or {}; sc, sa = scope(current())
    p = q(f"SELECT p.* FROM policies p WHERE p.id=? AND {sc}", (d.get("policy_id"),) + sa, one=True)
    if not p: return bad("Choose one of your policies")
    f, t = pdate(d.get("valid_from", "")), pdate(d.get("valid_to", ""))
    if not f or not t or t <= f: return bad("Valid-to must be after valid-from")
    if not d.get("from_location") or not d.get("to_location"): return bad("From and To locations are required")
    try: si = float(d.get("sum_insured"))
    except (TypeError, ValueError): return bad("Sum insured must be a number")
    if si <= 0: return bad("Sum insured must be above zero")
    if p["sum_insured"] and si > p["sum_insured"]: return bad("Sum insured cannot be more than the policy sum insured")
    cid = run("""INSERT INTO certificates(policy_id,from_location,to_location,valid_from,valid_to,mode,sum_insured,status,created_at)
                 VALUES(?,?,?,?,?,?,?,'Submitted',?)""", (p["id"], d["from_location"], d["to_location"], f.isoformat(), t.isoformat(),
                 d.get("mode") or "Self-propelled, with cargo on board", si, now()))
    plan = q("SELECT deductible FROM plans WHERE id=?", (p["plan_id"],), one=True)
    if plan: run("UPDATE certificates SET deductible=? WHERE id=?", (plan["deductible"], cid))
    for uid in [r["id"] for r in q("SELECT id FROM users WHERE role='admin'")]: push(uid, "certificate", f"New certificate request #{cid} waits for approval.")
    audit("request certificate", str(cid)); return jsonify(ok=True)

# POST /api/certificates/<int:cid>/issue : admin approves: number + PDF + QR, locked
@bp.post("/api/certificates/<int:cid>/issue")
@need("admin")
def issue(cid):
    c = q(CERT_SQL + " WHERE c.id=?", (cid,), one=True)
    if not c or c["status"] != "Submitted": return bad("Only submitted requests can be approved")
    if pstatus({"status": c["pstat"], "end_date": c["end_date"]}) in ("Expired", "Cancelled"): return bad("Policy is not active, certificate cannot be issued")
    u = current(); num = f"STC-{today().year}-{cid:06d}"
    run("UPDATE certificates SET certificate_number=?, status='Issued', issued_by=?, issued_at=? WHERE id=?", (num, u["name"], now(), cid))
    c = q(CERT_SQL + " WHERE c.id=?", (cid,), one=True)
    try:
        path = make_pdf(c, request.host_url.rstrip("/"))
    except Exception as e:                      # PDF could not be written: undo the approval so the request can be tried again
        run("UPDATE certificates SET certificate_number=NULL, status='Submitted', issued_by=NULL, issued_at=NULL WHERE id=?", (cid,))
        return bad("The PDF could not be created: " + str(e), 500)
    run("UPDATE certificates SET pdf_path=? WHERE id=?", (path, cid))  # issued certificates are locked: no edit endpoint exists
    cu = q("SELECT cl.user_id FROM policies p JOIN clients cl ON cl.id=p.client_id WHERE p.id=?", (c["policy_id"],), one=True)
    notify(cu["user_id"], "certificate issued", num); audit("issue certificate", num)
    return jsonify(ok=True, number=num)

# POST /api/certificates/<int:cid>/cancel : admin cancels
@bp.post("/api/certificates/<int:cid>/cancel")
@need("admin")
def cancel_cert(cid):
    run("UPDATE certificates SET status='Cancelled' WHERE id=?", (cid,)); audit("cancel certificate", str(cid)); return jsonify(ok=True)

def own_cert(cid):
    rows = cert_list(current(), "AND c.id=?", (cid,))
    c = rows[0] if rows and rows[0]["pdf_path"] else None
    if c and not os.path.exists(c["pdf_path"]):  # PDF file was deleted or the project was moved: build it again
        full = q(CERT_SQL + " WHERE c.id=?", (cid,), one=True)
        c["pdf_path"] = make_pdf(full, request.host_url.rstrip("/"))
        run("UPDATE certificates SET pdf_path=? WHERE id=?", (c["pdf_path"], cid))
    return c

# GET /api/certificates/<int:cid>/pdf : view or download (?dl=1) the PDF
@bp.get("/api/certificates/<int:cid>/pdf")
@need()
def cert_pdf(cid):
    c = own_cert(cid)
    if not c: return bad("Certificate not found or not issued yet", 404)
    audit("download" if request.args.get("dl") else "view pdf", c["certificate_number"])
    return send_file(c["pdf_path"], mimetype="application/pdf", as_attachment=bool(request.args.get("dl")), download_name=c["certificate_number"] + ".pdf")

# POST /api/certificates/<int:cid>/email : email the PDF
@bp.post("/api/certificates/<int:cid>/email")
@need()
def cert_email(cid):
    c = own_cert(cid); to = (request.json or {}).get("to", "")
    if not c: return bad("Certificate not found or not issued yet", 404)
    if not EMAIL.match(to): return bad("Enter a valid email address")
    sent = send_mail(to, f"Certificate {c['certificate_number']}", "Please find your marine transfer insurance certificate attached.", c["pdf_path"])
    notify(current()["id"], "certificate email", f"{c['certificate_number']} -> {to}"); audit("email", c["certificate_number"])
    return jsonify(ok=True, message="Email sent" if sent else "Email logged (set SMTP_HOST to really send)")

# GET /api/verify/<num> : PUBLIC: status without private data
@bp.get("/api/verify/<num>")  # public: no private information
def verify(num):
    rows = q(CERT_SQL + " WHERE c.certificate_number=?", (num,), one=True)
    if not rows: return bad("Certificate not found", 404)
    return jsonify({"status": {"Issued": "Valid"}.get(cstatus(rows), cstatus(rows)), "number": num, "ship": rows["ship_name"], "imo": rows["imo"],
                    "from": rows["from_location"], "to": rows["to_location"], "valid_from": rows["valid_from"], "valid_to": rows["valid_to"], "cover": rows["cover"]})


# POST /api/certificates/<id>/renew : renewal request = copy of the old certificate with the next dates (opens 30 days before expiry)
@bp.post("/api/certificates/<int:cid>/renew")
@need()
def renew_cert(cid):
    rows = cert_list(current(), "AND c.id=?", (cid,))
    if not rows: return bad("Certificate not found", 404)
    c = rows[0]; left = (dt.date.fromisoformat(c["valid_to"]) - today()).days
    if c["status"] not in ("Issued", "Expired"): return bad("Only issued certificates can be renewed")
    if left > 30: return bad("Renewal opens 30 days before the certificate expires")
    if q("SELECT 1 FROM certificates WHERE renewed_from=?", (cid,), one=True): return bad("A renewal was already requested")
    if pstatus({"status": c["pstat"], "end_date": c["end_date"]}) in ("Expired", "Cancelled"): return bad("Renew the policy first")
    span = (dt.date.fromisoformat(c["valid_to"]) - dt.date.fromisoformat(c["valid_from"])).days
    start = max(dt.date.fromisoformat(c["valid_to"]) + dt.timedelta(1), today()); end = min(start + dt.timedelta(span), dt.date.fromisoformat(c["end_date"]))
    if end <= start: return bad("The policy ends too soon. Renew the policy first")
    new = run("""INSERT INTO certificates(policy_id,from_location,to_location,valid_from,valid_to,mode,sum_insured,deductible,status,renewed_from,created_at)
                 VALUES(?,?,?,?,?,?,?,?,'Submitted',?,?)""", (c["policy_id"], c["from_location"], c["to_location"], start.isoformat(), end.isoformat(), c["mode"], c["sum_insured"], c["deductible"], cid, now()))
    for uid in [r["id"] for r in q("SELECT id FROM users WHERE role='admin'")]: push(uid, "certificate", f"Renewal request #{new} for certificate {c['certificate_number']} waits for approval.")
    audit("renew certificate", c["certificate_number"]); return jsonify(ok=True)
