"""routes/reviews.py - Broker directory with ratings and reviews. Clients can choose a broker and review the broker they worked with."""
from flask import Blueprint
from ..core import *

bp = Blueprint("reviews", __name__)


# GET /api/directory : active brokers with average rating, review count and the latest reviews
@bp.get("/api/directory")
@need()
def directory():
    u = current(); cid = ids(u)[0] if u["role"] == "client" else None
    mine = q("SELECT broker_id FROM clients WHERE id=?", (cid,), one=True)["broker_id"] if cid else None
    out = []
    for b in q("SELECT b.id, u.name, u.company, b.category FROM brokers b JOIN users u ON u.id=b.user_id WHERE b.deleted_at IS NULL AND b.status='Active' ORDER BY b.id"):
        r = q("SELECT ROUND(AVG(rating),1) avg, COUNT(*) n FROM reviews WHERE broker_id=?", (b["id"],), one=True)
        b.update(avg=r["avg"] or 0, count=r["n"], clients=q("SELECT COUNT(*) n FROM clients WHERE broker_id=?", (b["id"],), one=True)["n"],
                 reviews=q("""SELECT r.rating, r.comment, r.created_at, COALESCE(NULLIF(u.company,''),u.name) client FROM reviews r JOIN clients c ON c.id=r.client_id
                              JOIN users u ON u.id=c.user_id WHERE r.broker_id=? ORDER BY r.id DESC LIMIT 5""", (b["id"],)),
                 mine=(mine == b["id"]), can_review=bool(cid and (mine == b["id"] or q("SELECT 1 FROM policies WHERE client_id=? AND broker_id=?", (cid, b["id"]), one=True))))
        out.append(b)
    return jsonify(out)


# POST /api/brokers/<id>/reviews : a client rates (1-5) and comments on a broker he worked with (one review per client, can be changed)
@bp.post("/api/brokers/<int:bid>/reviews")
@need("client")
def write_review(bid):
    d = request.json or {}; cid = ids(current())[0]
    cl = q("SELECT * FROM clients WHERE id=?", (cid,), one=True)
    if not (cl["broker_id"] == bid or q("SELECT 1 FROM policies WHERE client_id=? AND broker_id=?", (cid, bid), one=True)):
        return bad("You can review a broker only after choosing him or having a policy with him")
    try: rating = int(d.get("rating"))
    except (TypeError, ValueError): return bad("Choose a rating from 1 to 5")
    comment = str(d.get("comment", "")).strip()[:500]
    if not 1 <= rating <= 5: return bad("Choose a rating from 1 to 5")
    run("""INSERT INTO reviews(broker_id,client_id,rating,comment,created_at) VALUES(?,?,?,?,?)
           ON CONFLICT(broker_id,client_id) DO UPDATE SET rating=excluded.rating, comment=excluded.comment, created_at=excluded.created_at""", (bid, cid, rating, comment, now()))
    audit("review broker", str(bid)); return jsonify(ok=True)


# POST /api/me/broker : a client chooses his broker
@bp.post("/api/me/broker")
@need("client")
def choose_broker():
    bid = (request.json or {}).get("broker_id"); b = q("SELECT b.*, u.name FROM brokers b JOIN users u ON u.id=b.user_id WHERE b.id=? AND b.deleted_at IS NULL AND b.status='Active'", (bid,), one=True)
    if not b: return bad("Broker not found")
    u = current(); cid = ids(u)[0]
    run("UPDATE clients SET broker_id=? WHERE id=?", (b["id"], cid))
    run("UPDATE policies SET broker_id=? WHERE client_id=?", (b["id"], cid))      # the new broker also handles the existing policies
    push(b["user_id"], "client", f"{u['name']} chose you as broker. Please collect the client's information and documents.")
    audit("choose broker", str(b["id"])); return jsonify(ok=True)
