"""routes/records.py - Records module: searchable certificate list, CSV export, admin audit log."""
from flask import Blueprint
from ..core import *

bp = Blueprint("records", __name__)

def record_rows():
    rows = cert_list(current()); t = request.args.get("q", "").lower(); st = request.args.get("status", "")
    return [r for r in rows if (not st or r["status"] == st) and
            (not t or t in " ".join(str(r[k]) for k in ("certificate_number", "ship_name", "insured", "policy_number", "broker")).lower())]

# GET /api/records : search + filter
@bp.get("/api/records")
@need()
def records(): return jsonify(record_rows())

# GET /api/records.csv : CSV export
@bp.get("/api/records.csv")
@need()
def records_csv():
    out = io.StringIO(); w = csv.writer(out); cols = ["certificate_number", "policy_number", "ship_name", "insured", "broker", "from_location", "to_location", "valid_from", "valid_to", "sum_insured", "status"]
    w.writerow(cols); [w.writerow([r[c] for c in cols]) for r in record_rows()]
    return send_file(io.BytesIO(out.getvalue().encode()), mimetype="text/csv", as_attachment=True, download_name="records.csv")

# GET /api/audit : admin: who did what and when
@bp.get("/api/audit")
@need("admin")
def audit_log():
    return jsonify(q("SELECT a.time, COALESCE(u.name,'-') user, a.action, a.target FROM audit a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.id DESC LIMIT 200"))
