"""routes/people.py - Clients and brokers module."""
from flask import Blueprint
from ..core import *

bp = Blueprint("people", __name__)

# GET /api/clients : client table
@bp.get("/api/clients")
@need("broker", "admin")
def clients():
    u = current(); w, a = ("", ()) if u["role"] == "admin" else ("WHERE cl.broker_id=?", (ids(u)[1],))
    return jsonify(q(f"""SELECT cl.id, cu.name, cu.company, cu.email, cl.broker_id, cu.status, cl.kyc_status, cl.country,
        COALESCE(NULLIF(bu.company,''),bu.name,'Unassigned') broker,
        (SELECT COUNT(*) FROM policies p WHERE p.client_id=cl.id) policies
        FROM clients cl JOIN users cu ON cu.id=cl.user_id LEFT JOIN brokers b ON b.id=cl.broker_id LEFT JOIN users bu ON bu.id=b.user_id {w}""", a))

# PUT /api/clients/<int:cid> : admin assigns a broker
@bp.put("/api/clients/<int:cid>")
@need("admin")
def assign_broker(cid):
    run("UPDATE clients SET broker_id=? WHERE id=?", ((request.json or {}).get("broker_id") or None, cid)); audit("assign broker", f"client {cid}")
    return jsonify(ok=True)

# GET /api/brokers : broker table
@bp.get("/api/brokers")
@need("admin")
def brokers():
    return jsonify(q("""SELECT b.id, u.name, u.email, u.company, b.category, b.status FROM brokers b JOIN users u ON u.id=b.user_id
                        WHERE b.deleted_at IS NULL"""))

# POST /api/brokers : admin adds a broker
@bp.post("/api/brokers")
@need("admin")
def add_broker():
    d = request.json or {}
    if not EMAIL.match(d.get("email", "")) or q("SELECT 1 FROM users WHERE email=?", (d["email"].lower(),)): return bad("Valid, unique email required")
    if not d.get("name") or not strong(d.get("password", "")): return bad("Name required. " + PW_MSG)
    uid = run("INSERT INTO users(name,email,phone,password,role,company) VALUES(?,?,?,?, 'broker', ?)",
              (d["name"], d["email"].lower(), d.get("phone", ""), gph(d["password"]), d.get("company", "")))
    run("INSERT INTO brokers(user_id,category) VALUES(?,?)", (uid, d.get("category", "Marine"))); audit("add broker", d["email"])
    return jsonify(ok=True)

# PUT /api/brokers/<int:bid> : admin edits a broker
@bp.put("/api/brokers/<int:bid>")
@need("admin")
def edit_broker(bid):
    d = request.json or {}
    run("UPDATE brokers SET category=COALESCE(?,category), status=COALESCE(?,status) WHERE id=?", (d.get("category"), d.get("status"), bid))
    audit("edit broker", str(bid)); return jsonify(ok=True)

# DELETE /api/brokers/<int:bid> : soft delete (hidden, not erased)
@bp.delete("/api/brokers/<int:bid>")
@need("admin")
def del_broker(bid):  # soft delete: hidden, not erased, so old records stay correct
    run("UPDATE brokers SET deleted_at=?, status='Inactive' WHERE id=?", (now(), bid))
    run("UPDATE users SET status='Inactive' WHERE id=(SELECT user_id FROM brokers WHERE id=?)", (bid,))
    audit("delete broker", str(bid)); return jsonify(ok=True)
