"""routes/policies.py - Policies: list, create (plan + automatic premium + invoice), cancel, renew."""
from flask import Blueprint
from ..core import *

bp = Blueprint("policies", __name__)


def policy_rows(u):
    sc, sa = scope(u)
    rows = q(POL_SQL + f" WHERE {sc} ORDER BY p.id DESC", sa)
    for p in rows:
        p["status"] = pstatus(p)                                                          # Active / Expiring Soon / Expired / Cancelled
        p["days_left"] = (dt.date.fromisoformat(p["end_date"]) - today()).days
        p["renewed"] = bool(q("SELECT 1 FROM policies WHERE renewed_from=?", (p["id"],), one=True))
    return rows


# GET /api/policies : policies this role may see
@bp.get("/api/policies")
@need()
def policies(): return jsonify(policy_rows(current()))


# POST /api/policies : create a policy with its ship. The premium is calculated by the server from the plan (cannot be typed in).
@bp.post("/api/policies")
@need()
def add_policy():
    d = request.json or {}; u = current(); cid = ids(u)[0] if u["role"] == "client" else None
    if u["role"] != "client":
        try: cid = int(d.get("client_id"))
        except (TypeError, ValueError): return bad("Choose a client")
    if not cid or not client_ok(u, cid): return bad("Choose one of your clients")
    cl = q("SELECT * FROM clients WHERE id=?", (cid,), one=True)
    plan = q("SELECT * FROM plans WHERE id=? AND active=1", (d.get("plan_id"),), one=True)
    if not plan: return bad("Choose an insurance plan")
    if not re.fullmatch(r"\d{7}", d.get("imo", "")): return bad("IMO number must be 7 digits")
    st, en = pdate(d.get("start_date", "")), pdate(d.get("end_date", ""))
    if not st or not en or en <= st: return bad("End date must be after start date")
    try: si = float(d.get("sum_insured")); ton = int(d.get("tonnage") or 0); yb = int(d.get("year_built") or 0)
    except (TypeError, ValueError): return bad("Sum insured, tonnage and year built must be numbers")
    if si <= 0 or not d.get("ship_name"): return bad("Ship name and sum insured are required")
    if yb and not (1900 <= yb <= today().year): return bad("Enter a real year built")
    war, bbb = int(bool(d.get("war_strikes"))), int(bool(d.get("bbb")))
    qt = quote(plan, si, yb, war, bbb, cid)
    sid = run("INSERT INTO ships(name,imo,flag,type,tonnage,year_built,owner_client_id) VALUES(?,?,?,?,?,?,?)", (d["ship_name"], d["imo"], d.get("flag", ""), d.get("ship_type", ""), ton, yb, cid))
    pid = run("INSERT INTO policies(client_id,broker_id,ship_id,type,premium,start_date,end_date,plan_id,sum_insured,war_strikes,bbb) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
              (cid, cl["broker_id"], sid, plan["name"], qt["premium"], st.isoformat(), en.isoformat(), plan["id"], si, war, bbb))
    num = f"MTP-{today().year}-{pid:06d}"; run("UPDATE policies SET policy_number=? WHERE id=?", (num, pid))
    create_invoice(pid, cid, qt["premium"], f"Premium for policy {num}")
    for uid in parties(pid): push(uid, "policy", f"Policy {num} created. Premium USD {qt['premium']:,.0f}. An invoice was issued.")
    audit("create policy", num); return jsonify(ok=True, policy_number=num, premium=qt["premium"])


# POST /api/policies/<id>/cancel : admin cancels a policy
@bp.post("/api/policies/<int:pid>/cancel")
@need("admin")
def cancel_policy(pid):
    run("UPDATE policies SET status='Cancelled' WHERE id=?", (pid,)); audit("cancel policy", str(pid)); return jsonify(ok=True)


# POST /api/policies/<id>/renew : new one-year policy after the old one (opens 60 days before the end), with a new invoice
@bp.post("/api/policies/<int:pid>/renew")
@need()
def renew_policy(pid):
    u = current(); sc, sa = scope(u)
    p = q(f"SELECT p.* FROM policies p WHERE p.id=? AND {sc}", (pid,) + sa, one=True)
    if not p: return bad("Policy not found", 404)
    st = pstatus(p); left = (dt.date.fromisoformat(p["end_date"]) - today()).days
    if st == "Cancelled": return bad("Cancelled policies cannot be renewed")
    if left > 60: return bad("Renewal opens 60 days before the policy ends")
    if q("SELECT 1 FROM policies WHERE renewed_from=?", (pid,), one=True): return bad("This policy was already renewed")
    plan = q("SELECT * FROM plans WHERE id=?", (p["plan_id"],), one=True)
    ship = q("SELECT * FROM ships WHERE id=?", (p["ship_id"],), one=True)
    si = p["sum_insured"] or 0
    qt = quote(plan, si, ship["year_built"] or 0, p["war_strikes"], p["bbb"], p["client_id"]) if plan and si else {"premium": p["premium"]}
    start = dt.date.fromisoformat(p["end_date"]) + dt.timedelta(1) if left >= 0 else today()
    end = start + dt.timedelta(364)
    nid = run("INSERT INTO policies(client_id,broker_id,ship_id,type,premium,start_date,end_date,plan_id,sum_insured,war_strikes,bbb,renewed_from) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
              (p["client_id"], p["broker_id"], p["ship_id"], p["type"], qt["premium"], start.isoformat(), end.isoformat(), p["plan_id"], p["sum_insured"], p["war_strikes"], p["bbb"], pid))
    num = f"MTP-{today().year}-{nid:06d}"; run("UPDATE policies SET policy_number=? WHERE id=?", (num, nid))
    create_invoice(nid, p["client_id"], qt["premium"], f"Renewal premium for policy {num}")
    for uid in parties(nid): push(uid, "policy", f"Policy {p['policy_number']} was renewed as {num}. Premium USD {qt['premium']:,.0f}.")
    audit("renew policy", f"{p['policy_number']} -> {num}"); return jsonify(ok=True, policy_number=num, premium=qt["premium"])
