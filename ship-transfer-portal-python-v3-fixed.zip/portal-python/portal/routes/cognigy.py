"""routes/cognigy.py - everything the Cognigy.AI chatbot (Insurance Risk Guardian AI) needs from the portal.

Two parts:
  1) GET /api/chat/config and /api/chat/token   -> called by the BROWSER (js/cognigy-bot.js) with the normal login cookie.
        The token is a short-lived signed ticket that says "this chat belongs to user X". The browser hands it to Cognigy.
  2) /api/bot/...                                -> called by COGNIGY (HTTP Request nodes), never by the browser.
        Every call needs   X-BOT-KEY: <secret in data/bot.key>  (or X-API-Key)  (proves the call comes from our Cognigy project)
        and, for private data,   Authorization: Bearer <chat token>   (proves which user is chatting).
        The SAME role rules as the website apply (scope(): client = own data, broker = own clients, admin = all).

Business problems (not found, not allowed ...) are answered with HTTP 200 and {"ok": false, "error": "..."} so a Cognigy flow
can simply read the message. Only a wrong bot key gives HTTP 401. The login cookie is never used here, so these routes need no CSRF token.
"""
import secrets
from functools import wraps
from flask import Blueprint
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired
from ..core import *
from ..config import COGNIGY_ENABLED, COGNIGY_ENDPOINT_URL, COGNIGY_API_KEY, COGNIGY_TOKEN_TTL
from .claims import submit_claim
from .documents import best

bp = Blueprint("cognigy", __name__)
_signer = URLSafeTimedSerializer(SECRET_KEY, salt="cognigy-chat-v1")


def ok(**kw): return jsonify(ok=True, **kw)
def fail(msg, code="ERROR"): return jsonify(ok=False, error=msg, code=code)       # HTTP 200 on purpose (see top of file)


# ------------------------------------------------------------------ 1) browser side
# GET /api/chat/config : tells the browser which Cognigy endpoint to open (public)
@bp.get("/api/chat/config")
def chat_config():
    return jsonify(enabled=bool(COGNIGY_ENABLED and COGNIGY_ENDPOINT_URL), endpoint=COGNIGY_ENDPOINT_URL)


# GET /api/chat/token : signed chat ticket for the logged-in user (guests get role "guest" and no token)
@bp.get("/api/chat/token")
def chat_token():
    u = current()
    if not u: return jsonify(role="guest", name="", token="", expires_in=0)
    return jsonify(id=u["id"], role=u["role"], name=u["name"], token=_signer.dumps({"uid": u["id"]}), expires_in=COGNIGY_TOKEN_TTL)


# ------------------------------------------------------------------ 2) Cognigy side
def bot(auth=True):
    """Decorator for bot routes. Checks the bot key; with auth=True it also needs a valid chat token and puts the user in g.bu."""
    def deco(f):
        @wraps(f)
        def w(*a, **k):
            sent = request.headers.get("X-BOT-KEY") or request.headers.get("X-API-Key") or ""     # custom header, or the HTTP Request node's built-in "API Key" header
            if not secrets.compare_digest(sent, COGNIGY_API_KEY):
                return jsonify(ok=False, error="Invalid bot key", code="BAD_KEY"), 401
            g.bu = None
            head = request.headers.get("Authorization", "")
            token = head[7:].strip() if head.lower().startswith("bearer ") else ""
            if token:
                try: uid = _signer.loads(token, max_age=COGNIGY_TOKEN_TTL)["uid"]
                except SignatureExpired: return fail("Your chat session expired. Please reload the page.", "TOKEN_EXPIRED") if auth else f(*a, **k)
                except (BadSignature, KeyError): return fail("Invalid chat token.", "BAD_TOKEN") if auth else f(*a, **k)
                u = q("SELECT * FROM users WHERE id=?", (uid,), one=True)
                if u and u["status"] == "Active": g.bu = u
            if auth and not g.bu: return fail("Please log in to the portal first, then I can look at your data.", "LOGIN_REQUIRED")
            return f(*a, **k)
        return w
    return deco


def num(v, default=None):
    try: return float(v)
    except (TypeError, ValueError): return default


# GET /api/bot/me : who is chatting (guest allowed)
@bp.get("/api/bot/me")
@bot(auth=False)
def bot_me():
    u = g.bu
    return ok(authenticated=bool(u), role=u["role"] if u else "guest", name=u["name"] if u else "")


# ---- public information (no login needed) ----
# GET /api/bot/plans?category=Cargo : active insurance plans
@bp.get("/api/bot/plans")
@bot(auth=False)
def bot_plans():
    cat = (request.args.get("category") or "").strip()
    rows = q("SELECT id, name, category, description, covers, rate, deductible FROM plans WHERE active=1" + (" AND LOWER(category) LIKE ?" if cat else "") + " ORDER BY id",
             (f"%{cat.lower()}%",) if cat else ())
    return ok(plans=rows, count=len(rows))


# POST /api/bot/quote : premium estimate. Body: plan_id OR plan_name, sum_insured, year_built (optional), war_strikes, bbb
@bp.post("/api/bot/quote")
@bot(auth=False)
def bot_quote():
    d = request.json or {}
    plan = q("SELECT * FROM plans WHERE id=? AND active=1", (int(d["plan_id"]),), one=True) if str(d.get("plan_id", "")).isdigit() else None
    if not plan and d.get("plan_name"):
        plan = q("SELECT * FROM plans WHERE active=1 AND LOWER(name) LIKE ? ORDER BY id", (f"%{str(d['plan_name']).lower()}%",), one=True)
    if not plan: return fail("I could not find that plan. Ask me to list the plans first.", "PLAN_NOT_FOUND")
    si = num(d.get("sum_insured"))
    if not si or si <= 0: return fail("The sum insured must be a number above zero.", "BAD_SUM")
    yb = int(num(d.get("year_built"), 0) or 0)
    if yb and not (1900 <= yb <= today().year): return fail("Please give a real year built.", "BAD_YEAR")
    u = g.bu; cid = ids(u)[0] if u and u["role"] == "client" else None
    out = quote(plan, si, yb, bool(d.get("war_strikes")), bool(d.get("bbb")), cid)
    out.update(plan=plan["name"], sum_insured=si, note="Indicative estimate only. The final premium is set when the policy is created.")
    return ok(**out)


# GET /api/bot/verify/<number> : PUBLIC certificate check (same data as the Verify page, no private information)
@bp.get("/api/bot/verify/<num>")
@bot(auth=False)
def bot_verify(num):
    c = q(CERT_SQL + " WHERE c.certificate_number=?", (num.strip().upper(),), one=True)
    if not c: return fail(f"No certificate with number {num} was found.", "NOT_FOUND")
    st = cstatus(c)
    return ok(number=c["certificate_number"], status={"Issued": "Valid"}.get(st, st), ship=c["ship_name"], imo=c["imo"], route=f"{c['from_location']} to {c['to_location']}",
              valid_from=c["valid_from"], valid_to=c["valid_to"], cover=c["cover"])


# ---- private information (login token needed; same scope as the website) ----
# GET /api/bot/certificates?number=STC-... : one certificate, or my latest 10
@bp.get("/api/bot/certificates")
@bot()
def bot_certs():
    u = g.bu; n = (request.args.get("number") or "").strip().upper()
    rows = cert_list(u, "AND c.certificate_number=?", (n,)) if n else cert_list(u)[:10]
    if n and not rows: return fail(f"I cannot find certificate {n} in your account.", "NOT_FOUND")
    out = []
    for c in rows:
        left = (dt.date.fromisoformat(c["valid_to"]) - today()).days
        out.append(dict(number=c["certificate_number"], status=c["status"], ship=c["ship_name"], imo=c["imo"], policy=c["policy_number"], route=f"{c['from_location']} to {c['to_location']}",
                        valid_from=c["valid_from"], valid_to=c["valid_to"], days_left=left, sum_insured=c["sum_insured"],
                        renewal_open=c["status"] in ("Issued", "Expired") and left <= 30, page="certificates.html"))
    return ok(certificates=out, count=len(out))


# GET /api/bot/policies?expiring=1 : my policies (expiring=1 -> only those that expire within 30 days)
@bp.get("/api/bot/policies")
@bot()
def bot_policies():
    sc, sa = scope(g.bu); out = []
    for p in q(POL_SQL + f" WHERE {sc} ORDER BY p.end_date", sa):
        st = pstatus(p)
        if request.args.get("expiring") and st != "Expiring Soon": continue
        out.append(dict(policy_number=p["policy_number"], ship=p["ship_name"], imo=p["imo"], plan=p["type"], status=st, start=p["start_date"], end=p["end_date"],
                        days_left=(dt.date.fromisoformat(p["end_date"]) - today()).days, premium=p["premium"], sum_insured=p.get("sum_insured"), broker=p["broker"], page="policies.html"))
    return ok(policies=out[:15], count=len(out))


# GET /api/bot/claims?number=CLM-... : my claims (one or the latest 10)
@bp.get("/api/bot/claims")
@bot()
def bot_claims():
    from .claims import CLAIM_SQL
    sc, sa = scope(g.bu); n = (request.args.get("number") or "").strip().upper()
    rows = q(CLAIM_SQL + f"WHERE {sc} " + ("AND c.claim_number=? " if n else "") + "ORDER BY c.id DESC", sa + ((n,) if n else ()))
    if n and not rows: return fail(f"I cannot find claim {n} in your account.", "NOT_FOUND")
    out = [dict(claim_number=c["claim_number"], status=c["status"], policy=c["policy_number"], ship=c["ship_name"], type=c["incident_type"], incident_date=c["incident_date"],
                amount_claimed=c["amount_claimed"], amount_approved=c["amount_approved"], decision_note=c["decision_note"] or "", updated=c["updated_at"], page="claims.html") for c in rows[:10]]
    return ok(claims=out, count=len(rows), incident_types=CLAIM_TYPES)


# POST /api/bot/claims : report a claim. Body: policy_number, incident_date (YYYY-MM-DD), incident_type, description, amount_claimed
@bp.post("/api/bot/claims")
@bot()
def bot_claim_new():
    d = dict(request.json or {}); sc, sa = scope(g.bu)
    p = q(f"SELECT p.id FROM policies p WHERE p.policy_number=? AND {sc}", (str(d.get("policy_number", "")).strip().upper(),) + sa, one=True)
    if not p: return fail("I cannot find that policy number in your account.", "POLICY_NOT_FOUND")
    d["policy_id"] = p["id"]
    body, code = submit_claim(g.bu, d)                  # exactly the same checks as the website
    return ok(claim_number=body["claim_number"], status="Submitted", page="claims.html") if code == 200 else fail(body["error"], "CLAIM_REJECTED")


# GET /api/bot/invoices?status=Unpaid : my invoices (Paid / Unpaid / Overdue)
@bp.get("/api/bot/invoices")
@bot()
def bot_invoices():
    from .invoices import rows_for
    st = (request.args.get("status") or "").strip().capitalize()
    rows = [r for r in rows_for(g.bu) if not st or r["status"] == st]
    out = [dict(invoice_number=r["invoice_number"], policy=r["policy_number"], amount=r["amount"], status=r["status"], due_date=r["due_date"], page="invoices.html") for r in rows[:10]]
    return ok(invoices=out, count=len(rows), total_open=round(sum(r["amount"] for r in rows if r["status"] != "Paid"), 2))


# GET /api/bot/brokers : broker ratings (like the Find a Broker page)
@bp.get("/api/bot/brokers")
@bot()
def bot_brokers():
    out = []
    for b in q("SELECT b.id, u.name, u.company, b.category FROM brokers b JOIN users u ON u.id=b.user_id WHERE b.deleted_at IS NULL AND b.status='Active' ORDER BY b.id"):
        r = q("SELECT ROUND(AVG(rating),1) avg, COUNT(*) n FROM reviews WHERE broker_id=?", (b["id"],), one=True)
        last = q("SELECT rating, comment FROM reviews WHERE broker_id=? ORDER BY id DESC LIMIT 1", (b["id"],), one=True)
        out.append(dict(name=b["name"], company=b["company"], category=b["category"], rating=r["avg"] or 0, reviews=r["n"], latest_review=last["comment"] if last else "", page="directory.html"))
    return ok(brokers=sorted(out, key=lambda x: -x["rating"]))


# GET /api/bot/documents : which required documents are still missing (clients only)
@bp.get("/api/bot/documents")
@bot()
def bot_documents():
    u = g.bu
    if u["role"] != "client": return fail("The document checklist is shown for client accounts. Brokers and admins open the Client File page.", "CLIENT_ONLY")
    cid = ids(u)[0]; docs = q("SELECT doc_type, status FROM documents WHERE client_id=?", (cid,))
    kyc = q("SELECT kyc_status FROM clients WHERE id=?", (cid,), one=True)["kyc_status"]
    req = [{"type": t, "status": best(docs, t)} for t in REQUIRED_DOCS]
    return ok(kyc_status=kyc, required=req, missing=[r["type"] for r in req if r["status"] in ("Missing", "Rejected")], page="clientfile.html")


# POST /api/bot/handover : leave a message for a human (shows in the admin Inbox). Body: message, topic, email (guests only)
@bp.post("/api/bot/handover")
@bot(auth=False)
def bot_handover():
    d = request.json or {}; u = g.bu
    msg = str(d.get("message", "")).strip()
    email = u["email"] if u else str(d.get("email", "")).strip()
    if len(msg) < 10: return fail("Please describe what you need help with (at least 10 characters).", "BAD_MESSAGE")
    if not EMAIL.match(email): return fail("Please give an email address so we can reply.", "BAD_EMAIL")
    run("INSERT INTO messages(name,email,topic,message,created_at) VALUES(?,?,?,?,?)",
        ((u["name"] if u else str(d.get("name") or "Chatbot visitor"))[:100], email, ("Chatbot: " + str(d.get("topic") or "handover"))[:60], msg[:2000], now()))
    for a in q("SELECT id FROM users WHERE role='admin'"): push(a["id"], "contact", f"Chatbot handover from {email}: {msg[:80]}")
    audit("chatbot handover", email, u["id"] if u else 0)
    return ok(message="Thank you. A team member will reply by email.")
