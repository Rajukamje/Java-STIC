"""routes/helpbot.py - Help agent module (rule based). Replace with Cognigy if you like."""
from flask import Blueprint
from ..core import *

bp = Blueprint("helpbot", __name__)

HELP = [
    ("claim", "To report a loss open Claims > Report a claim, choose the policy, the incident date, type and amount. Upload evidence in My Documents. An admin reviews it: Under Review, then Approved or Rejected, then Paid."),
    ("renew", "Open Policies (or Certificates) and click Renew. Renewal opens 60 days before a policy and 30 days before a certificate expires. You also get notifications 30, 15 and 7 days before."),
    ("invoice|pay|bill", "Open Invoices to see what is due. Click Pay, choose a method, and download the invoice PDF. Overdue invoices create a notification."),
    ("document|upload|kyc", "Open My Documents (clients) or the client file (brokers). Required: ID / company registration, ship registry, class certificate and survey report. Your broker verifies each one."),
    ("broker|review|rating", "Open Find a Broker to compare ratings and reviews, choose your broker, and rate him after working together."),
    ("plan|cover|icc|insurance type", "Open Insurance Plans to compare Hull, Cargo ICC A/B/C, Liability, Builder's Risk and Inland Marine, and use the quote calculator."),("imo", "An IMO number is the unique 7-digit identification number of a ship."),
        ("sum insured", "Sum insured is the maximum amount the insurance covers."), ("premium", "Premium is the price paid for the insurance."),
        ("deductible", "The deductible is the part of a loss you pay yourself."),
        ("pending|status|submitted", "New requests are 'Submitted' until an admin approves them. Then they become 'Issued' and the PDF is available."),
        ("create|request|how", "Open Certificates > Request Certificate, pick a policy, enter route, dates and sum insured. An admin approves it and the PDF with QR code is generated."),
        ("verify|qr", "Scan the QR code or open Verify Certificate and type the number. It shows Valid, Expired or Cancelled."),
        ("policy", "A policy is the insurance contract. One policy can have many certificates.")]

# POST /api/help : help agent answer
@bp.post("/api/help")
def help_agent():
    m = (request.json or {}).get("message", "").lower(); u = current()
    if "expir" in m:
        if not u: return jsonify(reply="Please log in first so I can check your policies.")
        sc, sa = scope(u); rows = [p for p in q(f"SELECT p.* FROM policies p WHERE {sc}", sa) if pstatus(p) == "Expiring Soon"]
        return jsonify(reply="Expiring within 30 days: " + (", ".join(f"{p['policy_number']} ({p['end_date']})" for p in rows) or "none."))
    for pat, ans in HELP:
        if re.search(pat, m): return jsonify(reply=ans)
    return jsonify(reply="I'm not sure about that. I'll hand you to a human: support@example.com. I can never promise approval of a claim or certificate.")
