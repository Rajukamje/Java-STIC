"""routes/documents.py - The broker's client file: client information, KYC status and uploaded documents (secure upload + download)."""
from flask import Blueprint
from werkzeug.utils import secure_filename
from ..core import *

bp = Blueprint("documents", __name__)

ALLOWED = {"pdf": b"%PDF", "png": b"\x89PNG", "jpg": b"\xff\xd8", "jpeg": b"\xff\xd8", "docx": b"PK", "xlsx": b"PK"}   # extension -> first bytes of a real file


def toint(v):
    try: return int(v)
    except (TypeError, ValueError): return None


def best(docs, doc_type):
    """Status of a required document type: Verified > Pending > Rejected > Missing."""
    st = {d["status"] for d in docs if d["doc_type"] == doc_type}
    return next((s for s in ("Verified", "Pending", "Rejected") if s in st), "Missing")


# GET /api/clientfile : everything about one client (client sees own file; broker / admin pass ?id=)
@bp.get("/api/clientfile")
@need()
def clientfile():
    u = current(); cid = ids(u)[0] if u["role"] == "client" else toint(request.args.get("id"))
    if not cid or not client_ok(u, cid): return bad("Client not found", 404)
    cl = q("""SELECT cl.*, u.name, u.email, u.phone, u.company, u.address, COALESCE(NULLIF(bu.company,''),bu.name,'Unassigned') broker
              FROM clients cl JOIN users u ON u.id=cl.user_id LEFT JOIN brokers b ON b.id=cl.broker_id LEFT JOIN users bu ON bu.id=b.user_id WHERE cl.id=?""", (cid,), one=True)
    docs = q("SELECT id, doc_type, filename, status, note, uploaded_at, policy_id, claim_id FROM documents WHERE client_id=? ORDER BY id DESC", (cid,))
    pols = q(POL_SQL + " WHERE p.client_id=? ORDER BY p.id DESC", (cid,))
    for p in pols: p["status"] = pstatus(p)
    return jsonify(client=cl, documents=docs, required=[{"type": t, "status": best(docs, t)} for t in REQUIRED_DOCS], doc_types=DOC_TYPES, policies=pols,
                   claims=q("SELECT c.claim_number, c.status, c.amount_claimed, c.incident_type FROM claims c JOIN policies p ON p.id=c.policy_id WHERE p.client_id=? ORDER BY c.id DESC", (cid,)),
                   staff=u["role"] != "client")


# PUT /api/clientfile : save client information (company registration, country, contact person, notes)
@bp.put("/api/clientfile")
@need()
def save_profile():
    d = request.json or {}; u = current(); cid = ids(u)[0] if u["role"] == "client" else toint(d.get("client_id"))
    if not cid or not client_ok(u, cid): return bad("Client not found", 404)
    run("UPDATE clients SET reg_no=?, country=?, contact_person=?, notes=? WHERE id=?",
        tuple(str(d.get(k, "")).strip()[:300] for k in ("reg_no", "country", "contact_person", "notes")) + (cid,))
    if u["role"] == "client": run("UPDATE clients SET kyc_status='Pending' WHERE id=? AND kyc_status='Verified'", (cid,))   # changed data must be checked again
    audit("edit client file", str(cid)); return jsonify(ok=True)


# POST /api/clientfile/kyc : broker / admin sets the KYC status. "Verified" needs every required document verified first.
@bp.post("/api/clientfile/kyc")
@need("broker", "admin")
def kyc():
    d = request.json or {}; cid = toint(d.get("client_id")); u = current()
    if not cid or not client_ok(u, cid): return bad("Client not found", 404)
    if d.get("status") not in ("Pending", "Verified", "Rejected"): return bad("Choose a status")
    if d["status"] == "Verified":
        docs = q("SELECT doc_type, status FROM documents WHERE client_id=?", (cid,))
        missing = [t for t in REQUIRED_DOCS if best(docs, t) != "Verified"]
        if missing: return bad("Verify these documents first: " + ", ".join(missing))
    run("UPDATE clients SET kyc_status=? WHERE id=?", (d["status"], cid))
    cu = q("SELECT user_id FROM clients WHERE id=?", (cid,), one=True)["user_id"]; push(cu, "kyc", f"Your client file status is now: {d['status']}.")
    audit("kyc " + d["status"].lower(), str(cid)); return jsonify(ok=True)


# POST /api/documents : upload one file (pdf, png, jpg, docx, xlsx; max 8 MB). The real file content is checked, the file gets a random name.
@bp.post("/api/documents")
@need()
def upload():
    u = current(); cid = ids(u)[0] if u["role"] == "client" else toint(request.form.get("client_id"))
    if not cid or not client_ok(u, cid): return bad("Choose a client you may upload for")
    f = request.files.get("file")
    if not f or not f.filename: return bad("Choose a file")
    ext = f.filename.rsplit(".", 1)[-1].lower() if "." in f.filename else ""
    if ext not in ALLOWED: return bad("Allowed file types: " + ", ".join(ALLOWED))
    if not f.read(8).startswith(ALLOWED[ext]): return bad("The file content does not match its type")
    f.seek(0)
    doc_type = request.form.get("doc_type")
    if doc_type not in DOC_TYPES: return bad("Choose a document type")
    pid, clid = toint(request.form.get("policy_id")), toint(request.form.get("claim_id"))
    if pid and not q("SELECT 1 FROM policies WHERE id=? AND client_id=?", (pid, cid), one=True): return bad("Policy does not belong to this client")
    if clid and not q("SELECT 1 FROM claims c JOIN policies p ON p.id=c.policy_id WHERE c.id=? AND p.client_id=?", (clid, cid), one=True): return bad("Claim does not belong to this client")
    os.makedirs(UP_DIR, exist_ok=True); stored = secrets.token_hex(16) + "." + ext
    f.save(os.path.join(UP_DIR, stored))
    did = run("INSERT INTO documents(client_id,policy_id,claim_id,doc_type,filename,stored_name,status,uploaded_by,uploaded_at) VALUES(?,?,?,?,?,?,'Pending',?,?)",
              (cid, pid, clid, doc_type, secure_filename(f.filename) or "document." + ext, stored, u["id"], now()))
    cl = q("SELECT cl.user_id cu, b.user_id bu FROM clients cl LEFT JOIN brokers b ON b.id=cl.broker_id WHERE cl.id=?", (cid,), one=True)
    for uid in {cl["cu"], cl["bu"]} - {u["id"], None}: push(uid, "document", f"New document uploaded: {doc_type}.")
    audit("upload document", str(did)); return jsonify(ok=True)


def doc_for(u, did):
    d = q("SELECT * FROM documents WHERE id=?", (did,), one=True)
    return d if d and client_ok(u, d["client_id"]) else None


# GET /api/documents/<id>/file : download (only if you may see this client)
@bp.get("/api/documents/<int:did>/file")
@need()
def download(did):
    d = doc_for(current(), did)
    if not d: return bad("Document not found", 404)
    audit("download document", str(did))
    return send_file(os.path.join(UP_DIR, d["stored_name"]), as_attachment=True, download_name=d["filename"])


# POST /api/documents/<id>/review : broker / admin verifies or rejects a document
@bp.post("/api/documents/<int:did>/review")
@need("broker", "admin")
def review_doc(did):
    d = doc_for(current(), did); data = request.json or {}
    if not d: return bad("Document not found", 404)
    if data.get("status") not in ("Verified", "Rejected"): return bad("Choose Verified or Rejected")
    note = str(data.get("note", "")).strip()[:300]
    if data["status"] == "Rejected" and not note: return bad("Please say why the document is rejected")
    run("UPDATE documents SET status=?, note=? WHERE id=?", (data["status"], note, did))
    cu = q("SELECT user_id FROM clients WHERE id=?", (d["client_id"],), one=True)["user_id"]; push(cu, "document", f"Your document ({d['doc_type']}) is {data['status']}." + (f" {note}" if note else ""))
    audit("document " + data["status"].lower(), str(did)); return jsonify(ok=True)


# DELETE /api/documents/<id> : remove a document that is still Pending (uploader or admin)
@bp.delete("/api/documents/<int:did>")
@need()
def delete_doc(did):
    u = current(); d = doc_for(u, did)
    if not d: return bad("Document not found", 404)
    if d["status"] != "Pending" or (u["role"] != "admin" and d["uploaded_by"] != u["id"]): return bad("Only your own pending documents can be removed")
    try: os.remove(os.path.join(UP_DIR, d["stored_name"]))
    except OSError: pass
    run("DELETE FROM documents WHERE id=?", (did,)); audit("delete document", str(did)); return jsonify(ok=True)
