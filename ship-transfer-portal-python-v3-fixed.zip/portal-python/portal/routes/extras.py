"""routes/extras.py - forgot / reset password, notifications, public statistics, newsletter and contact form."""
from flask import Blueprint
from ..core import *

bp = Blueprint("extras", __name__)


# POST /api/forgot : create a reset link that is valid 30 minutes
@bp.post("/api/forgot")
def forgot():
    email = (request.json or {}).get("email", "").strip().lower()
    u = q("SELECT * FROM users WHERE email=?", (email,), one=True)
    link = None
    if u:  # same answer whether the email exists or not (does not reveal accounts)
        token = secrets.token_urlsafe(24)
        run("INSERT INTO password_resets(token,user_id,expires) VALUES(?,?,?)", (token, u["id"], (dt.datetime.now() + dt.timedelta(minutes=30)).isoformat(timespec="seconds")))
        link = f"/reset.html?token={token}"; notify(u["id"], "password reset", f"Reset link (valid 30 minutes): {link}")
    return jsonify(ok=True, message="If this email exists, a reset link was sent. It expires in 30 minutes.", demo_link=link if DEMO_MODE else None)


# POST /api/reset : set a new password with the token
@bp.post("/api/reset")
def reset():
    d = request.json or {}; r = q("SELECT * FROM password_resets WHERE token=?", (d.get("token", ""),), one=True)
    if not r or r["expires"] < now(): return bad("Reset link is invalid or expired")
    if not strong(d.get("password", "")): return bad(PW_MSG)
    if d["password"] != d.get("confirm"): return bad("Passwords do not match")
    run("UPDATE users SET password=?, failed=0, locked_until=NULL WHERE id=?", (gph(d["password"]), r["user_id"]))
    run("DELETE FROM password_resets WHERE user_id=?", (r["user_id"],)); return jsonify(ok=True)


# GET /api/notifications : my notifications (expiry reminders 30/15/7 days, claims, invoices, documents ...). ?count=1 gives only the number of last 7 days.
@bp.get("/api/notifications")
@need()
def notifications():
    run_reminders(); uid = current()["id"]
    if request.args.get("count"):
        return jsonify(count=q("SELECT COUNT(*) n FROM notifications WHERE user_id=? AND sent_at >= ?", (uid, (dt.datetime.now() - dt.timedelta(days=7)).isoformat(timespec="seconds")), one=True)["n"])
    return jsonify(q("SELECT type, detail, sent_at FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 60", (uid,)))


# GET /api/stats : PUBLIC numbers for the landing page
@bp.get("/api/stats")
def stats():
    n = lambda sql: q(sql, one=True)["n"]
    return jsonify(certificates=n("SELECT COUNT(*) n FROM certificates WHERE status='Issued'"), policies=n("SELECT COUNT(*) n FROM policies"),
                   ships=n("SELECT COUNT(*) n FROM ships"), brokers=n("SELECT COUNT(*) n FROM brokers WHERE deleted_at IS NULL"))


# POST /api/newsletter : footer sign-up
@bp.post("/api/newsletter")
def newsletter():
    email = (request.json or {}).get("email", "").strip().lower()
    if not EMAIL.match(email): return bad("Enter a valid email")
    run("INSERT OR IGNORE INTO subscribers(email,created_at) VALUES(?,?)", (email, now())); return jsonify(ok=True)


# POST /api/contact : contact form
@bp.post("/api/contact")
def contact():
    d = request.json or {}
    if not d.get("name") or not EMAIL.match(d.get("email", "")) or len(str(d.get("message", "")).strip()) < 10: return bad("Name, a valid email and a message (10+ characters) are required")
    run("INSERT INTO messages(name,email,topic,message,created_at) VALUES(?,?,?,?,?)", (str(d["name"])[:100], d["email"], str(d.get("topic", "General"))[:60], str(d["message"])[:2000], now()))
    return jsonify(ok=True)


# GET /api/messages : admin inbox (contact messages + newsletter count)
@bp.get("/api/messages")
@need("admin")
def messages():
    return jsonify(messages=q("SELECT * FROM messages ORDER BY id DESC LIMIT 100"), subscribers=q("SELECT COUNT(*) n FROM subscribers", one=True)["n"])
