"""routes/plans.py - Insurance plans: public list, premium quote calculator, admin add / edit."""
from flask import Blueprint
from ..core import *

bp = Blueprint("plans", __name__)


def toint(v):
    try: return int(v)
    except (TypeError, ValueError): return None


# GET /api/plans : PUBLIC list of plans (admin can add ?all=1 to also see inactive plans)
@bp.get("/api/plans")
def plans():
    u = current(); every = bool(u and u["role"] == "admin" and request.args.get("all"))
    return jsonify(q("SELECT * FROM plans" + ("" if every else " WHERE active=1") + " ORDER BY id"))


# POST /api/quote : premium calculation with the full breakdown
@bp.post("/api/quote")
def quote_api():
    d = request.json or {}; plan = q("SELECT * FROM plans WHERE id=?", (toint(d.get("plan_id")),), one=True)
    if not plan: return bad("Choose a plan")
    try: si = float(d.get("sum_insured")); yb = int(d.get("year_built") or 0)
    except (TypeError, ValueError): return bad("Sum insured and year built must be numbers")
    if si <= 0: return bad("Sum insured must be above zero")
    if yb and not (1900 <= yb <= today().year): return bad("Enter a real year built")
    u = current(); cid = None
    if u and u["role"] == "client": cid = ids(u)[0]
    elif u and toint(d.get("client_id")) and client_ok(u, toint(d.get("client_id"))): cid = toint(d.get("client_id"))
    out = quote(plan, si, yb, bool(d.get("war_strikes")), bool(d.get("bbb")), cid); out["plan"] = plan["name"]
    return jsonify(out)


# POST /api/plans : admin adds a plan
@bp.post("/api/plans")
@need("admin")
def add_plan():
    d = request.json or {}
    try: rate, ded = float(d.get("rate")), float(d.get("deductible"))
    except (TypeError, ValueError): return bad("Rate and deductible must be numbers")
    if not d.get("name") or not d.get("category") or not (0 < rate <= 10) or ded < 0: return bad("Name, category, rate (0-10 %) and deductible are required")
    run("INSERT INTO plans(name,category,description,covers,rate,deductible) VALUES(?,?,?,?,?,?)", (d["name"], d["category"], d.get("description", ""), d.get("covers", ""), rate, ded))
    audit("add plan", d["name"]); return jsonify(ok=True)


# PUT /api/plans/<id> : admin changes rate, deductible or switches a plan on / off
@bp.put("/api/plans/<int:pid>")
@need("admin")
def edit_plan(pid):
    d = request.json or {}; p = q("SELECT * FROM plans WHERE id=?", (pid,), one=True)
    if not p: return bad("Plan not found", 404)
    try: rate, ded = float(d.get("rate", p["rate"])), float(d.get("deductible", p["deductible"]))
    except (TypeError, ValueError): return bad("Rate and deductible must be numbers")
    if not (0 < rate <= 10) or ded < 0: return bad("Rate must be 0-10 % and deductible 0 or more")
    run("UPDATE plans SET rate=?, deductible=?, active=? WHERE id=?", (rate, ded, int(d.get("active", p["active"])), pid))
    audit("edit plan", str(pid)); return jsonify(ok=True)
