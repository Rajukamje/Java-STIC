"""pdf_service.py - builds the certificate PDF (with QR code) and sends emails."""
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.utils import simpleSplit
from reportlab.pdfgen import canvas
from reportlab.graphics.barcode import qr
from reportlab.graphics.shapes import Drawing
from reportlab.graphics import renderPDF
from .core import *

# Send the PDF by email when SMTP_HOST is set (otherwise the caller just logs the email)
def send_mail(to, subject, body, attach):
    host = os.environ.get("SMTP_HOST")
    if not host: return False
    import smtplib; from email.message import EmailMessage
    m = EmailMessage(); m["From"] = os.environ.get("SMTP_FROM", "noreply@portal.local"); m["To"] = to; m["Subject"] = subject; m.set_content(body)
    m.add_attachment(open(attach, "rb").read(), maintype="application", subtype="pdf", filename=os.path.basename(attach))
    with smtplib.SMTP(host, int(os.environ.get("SMTP_PORT", 587))) as s:
        s.starttls()
        if os.environ.get("SMTP_USER"): s.login(os.environ["SMTP_USER"], os.environ.get("SMTP_PASS", ""))
        s.send_message(m)
    return True


# Draw the certificate page and save it in data/pdfs
def make_pdf(c, base):
    path = os.path.join(PDF_DIR, c["certificate_number"] + ".pdf")
    W, H = A4; p = canvas.Canvas(path, pagesize=A4); navy = colors.HexColor("#0b2a5b")
    p.setStrokeColor(navy); p.rect(25, 25, W - 50, H - 50); p.setFillColor(navy)
    p.setFont("Times-Bold", 26); p.drawString(60, H - 80, "ALLIANZ"); p.setFont("Helvetica", 8); p.drawString(60, H - 94, "MARINE INSURANCE (SAMPLE)")
    p.setFont("Helvetica", 8); p.drawRightString(W - 60, H - 70, "CERTIFICATE NO."); p.setFont("Helvetica-Bold", 14); p.drawRightString(W - 60, H - 86, c["certificate_number"])
    p.setFont("Times-Bold", 21); p.drawCentredString(W / 2, H - 140, "MARINE TRANSFER INSURANCE CERTIFICATE")
    p.setFont("Helvetica", 8); p.drawCentredString(W / 2, H - 156, "CERTIFICATE OF INSURANCE FOR SHIP TRANSFER")
    money = lambda x: f"USD {x:,.0f}"
    sections = [
        ("POLICY", [("Policy number", c["policy_number"]), ("Date of issue", c["issued_at"][:10]), ("Insured", c["insured"]),
                    ("Address", c["address"] or "-"), ("Broker", c["broker"])]),
        ("VESSEL DETAILS", [("Name", c["ship_name"]), ("IMO number", c["imo"]), ("Flag", c["flag"]), ("Type", c["ship_type"]), ("Gross tonnage", f"{c['tonnage']:,} GT")]),
        ("TRANSFER DETAILS", [("From", c["from_location"]), ("To", c["to_location"]), ("Valid from", c["valid_from"]), ("Valid to", c["valid_to"]), ("Mode", c["mode"])]),
        ("COVERAGE", [("Type of cover", c["cover"]), ("Sum insured", money(c["sum_insured"])), ("Deductible", money(c["deductible"])), ("Premium", money(c["premium"]))])]
    y = H - 195
    for title, rows in sections:
        p.setFillColor(navy); p.setFont("Helvetica-Bold", 10); p.drawString(60, y, title); y -= 15
        for k, v in rows:
            p.setFillColor(colors.grey); p.setFont("Helvetica", 9); p.drawString(70, y, k.upper()); p.setFillColor(colors.black); p.setFont("Helvetica-Bold", 10); p.drawString(190, y, str(v)); y -= 14
        y -= 8
    p.setFillColor(navy); p.setFont("Helvetica-Bold", 10); p.drawString(60, y, "CLAUSES AND CONDITIONS"); y -= 14
    txt = ("Subject to the Institute Time Clauses Hulls and the policy wording. Cover applies only while the vessel follows the declared route and remains "
           "within class. Towage or deviation requires prior written notice. Claims must be reported without delay. This certificate is subject to the policy terms and does not alter them.")
    p.setFillColor(colors.black); p.setFont("Helvetica", 9)
    for line in simpleSplit(txt, "Helvetica", 9, W - 120): p.drawString(60, y, line); y -= 12
    p.setFont("Times-Italic", 22); p.drawString(60, 120, c["issued_by"] or ""); p.line(60, 112, 280, 112)
    p.setFont("Helvetica", 8); p.drawString(60, 100, "Authorized signature - Underwriting"); 
    url = f"{base}/verify.html?n={c['certificate_number']}"; w = qr.QrCodeWidget(url); b = w.getBounds(); s = 80
    d = Drawing(s, s, transform=[s / (b[2] - b[0]), 0, 0, s / (b[3] - b[1]), 0, 0]); d.add(w); renderPDF.draw(d, p, W - 140, 70)
    p.setFont("Helvetica", 7); p.drawRightString(W - 150, 95, "Scan to verify"); p.drawRightString(W - 150, 85, c["certificate_number"])
    p.setFillColor(colors.grey); p.drawCentredString(W / 2, 45, "SAMPLE FOR DEMONSTRATION ONLY. NOT A VALID INSURANCE DOCUMENT. All names and numbers are fictional.")
    p.save(); return path



# Invoice PDF (returned as bytes, nothing is stored on disk)
def make_invoice_pdf(i):
    buf = io.BytesIO(); W, H = A4; p = canvas.Canvas(buf, pagesize=A4); navy = colors.HexColor("#0b2a5b")
    p.setFillColor(navy); p.setFont("Times-Bold", 26); p.drawString(60, H - 80, "ALLIANZ"); p.setFont("Helvetica-Bold", 22); p.drawRightString(W - 60, H - 80, "INVOICE")
    p.setFont("Helvetica", 9); p.setFillColor(colors.grey); p.drawString(60, H - 94, "MARINE INSURANCE (SAMPLE)")
    rows = [("Invoice number", i["invoice_number"]), ("Issue date", i["issue_date"]), ("Due date", i["due_date"]), ("Status", i["status"]),
            ("Bill to", i["client"]), ("Address", i["address"] or "-"), ("Policy", i["policy_number"]), ("Plan", i["plan"])]
    y = H - 150
    for k, v in rows:
        p.setFillColor(colors.grey); p.setFont("Helvetica", 9); p.drawString(60, y, k.upper()); p.setFillColor(colors.black); p.setFont("Helvetica-Bold", 11); p.drawString(190, y, str(v)); y -= 20
    p.setStrokeColor(navy); p.line(60, y - 5, W - 60, y - 5); y -= 30
    p.setFont("Helvetica", 11); p.drawString(60, y, i["description"]); p.setFont("Helvetica-Bold", 14); p.drawRightString(W - 60, y, f"USD {i['amount']:,.2f}"); y -= 40
    p.setFillColor(navy); p.setFont("Helvetica-Bold", 16); p.drawRightString(W - 60, y, f"TOTAL  USD {i['amount']:,.2f}")
    if i.get("paid_at"): p.setFillColor(colors.HexColor("#14602f")); p.setFont("Helvetica-Bold", 12); p.drawString(60, y, f"PAID on {i['paid_at'][:10]} ({i.get('method') or '-'})")
    p.setFillColor(colors.grey); p.setFont("Helvetica", 7); p.drawCentredString(W / 2, 45, "SAMPLE FOR DEMONSTRATION ONLY. NOT A VALID INSURANCE DOCUMENT. All names and numbers are fictional.")
    p.save(); return buf.getvalue()
