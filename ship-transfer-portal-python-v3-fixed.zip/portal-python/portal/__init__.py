"""portal/__init__.py - builds the Flask app: settings, security, database, all route modules and the reminder job."""
import os, threading, time
from flask import Flask, send_from_directory, send_file, abort
from .config import BASE, SECRET_KEY, COGNIGY_ENABLED, WEBCHAT_URL
from .core import close_db, run_reminders
from .security import init_security
from .seed import init_db
from .routes import auth, dashboard, people, policies, certificates, records, helpbot, extras, plans, claims, invoices, reviews, documents, cognigy


def create_app():
    app = Flask(__name__, static_folder=os.path.join(BASE, "static"), static_url_path="")   # static/ = the website pages
    app.secret_key = SECRET_KEY
    init_security(app)
    app.teardown_appcontext(close_db)                       # close the database after each request
    for module in (auth, dashboard, people, policies, certificates, records, helpbot, extras, plans, claims, invoices, reviews, documents, cognigy):
        app.register_blueprint(module.bp)                   # every module adds its /api/... routes
    app.add_url_rule("/", "home", lambda: send_from_directory(app.static_folder, "index.html"))   # landing page

    failed = {"at": 0}                                      # when the last download attempt failed (do not retry on every page)

    def webchat_js():
        """Cognigy webchat.js. GitHub cannot be used directly as a <script> (it is sent as a download, browsers refuse to run it),
        so the server fetches it once, saves it in static/vendor/webchat.js and serves it from here."""
        path = os.path.join(app.static_folder, "vendor", "webchat.js")
        if not os.path.exists(path) and COGNIGY_ENABLED and time.time() - failed["at"] > 600:
            try:
                import urllib.request
                with urllib.request.urlopen(urllib.request.Request(WEBCHAT_URL, headers={"User-Agent": "ship-portal"}), timeout=15) as r: data = r.read()
                if len(data) < 50000: raise ValueError("downloaded file is too small to be webchat.js")
                os.makedirs(os.path.dirname(path), exist_ok=True)
                with open(path + ".part", "wb") as f: f.write(data)
                os.replace(path + ".part", path)
            except Exception as e:
                failed["at"] = time.time(); app.logger.warning("Could not download Cognigy webchat.js (%s). The built-in help bubble is used instead.", e)
        if os.path.exists(path): return send_file(path, mimetype="application/javascript")
        abort(404)
    app.add_url_rule("/vendor/webchat.js", "webchat_js", webchat_js)

    init_db()                                               # tables + demo data
    with app.app_context(): run_reminders()                 # expiry / overdue notifications

    def reminder_loop():                                    # repeat every hour while the server runs
        while True:
            time.sleep(3600)
            with app.app_context(): run_reminders()
    if not app.config.get("TESTING"): threading.Thread(target=reminder_loop, daemon=True).start()
    return app
