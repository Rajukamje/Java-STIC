"""Tests for the chatbot API.   Run:  python tests/test_cognigy.py     (uses a temporary database, your real data is untouched)"""
import os, sys, tempfile, unittest, datetime as dt
tmp = tempfile.mkdtemp(); os.environ["PORTAL_DB"] = os.path.join(tmp, "t.db"); os.environ["COGNIGY_API_KEY"] = "test-key"; os.environ["SECRET_KEY"] = "x" * 32
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from portal import create_app
from portal.routes import cognigy as cg

KEY = {"X-BOT-KEY": "test-key"}


class BotApi(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = create_app(); cls.app.config["TESTING"] = True

    def login(self, email, pw, role):
        c = self.app.test_client(); csrf = c.get("/api/me").json["csrf"]
        r = c.post("/api/login", json=dict(email=email, password=pw, role=role), headers={"X-CSRF-Token": csrf}); self.assertEqual(r.status_code, 200, r.json)
        return c, c.get("/api/chat/token").json["token"]

    def auth(self, token): return {**KEY, "Authorization": "Bearer " + token}

    def test_config_and_guest_token(self):
        c = self.app.test_client()
        self.assertTrue(c.get("/api/chat/config").json["enabled"])
        t = c.get("/api/chat/token").json; self.assertEqual((t["role"], t["token"]), ("guest", ""))

    def test_csp_allows_cognigy(self):
        csp = self.app.test_client().get("/api/chat/config").headers["Content-Security-Policy"]
        self.assertIn("wss://*.cognigy.cloud", csp); self.assertIn("https://github.com", csp)

    def test_key_required(self):
        c = self.app.test_client()
        self.assertEqual(c.get("/api/bot/plans").status_code, 401)
        self.assertEqual(c.get("/api/bot/plans", headers={"X-BOT-KEY": "wrong"}).status_code, 401)
        self.assertTrue(c.get("/api/bot/plans", headers={"X-API-Key": "test-key"}).json["ok"])      # Cognigy's built-in API-key header works too

    def test_public_plans_quote_verify(self):
        c = self.app.test_client(); p = c.get("/api/bot/plans?category=Cargo", headers=KEY).json
        self.assertTrue(p["ok"]); self.assertGreater(p["count"], 0)
        q = c.post("/api/bot/quote", json=dict(plan_id=p["plans"][0]["id"], sum_insured=1000000, year_built=2000), headers=KEY).json
        self.assertTrue(q["ok"]); self.assertGreater(q["premium"], 0)
        self.assertFalse(c.post("/api/bot/quote", json=dict(plan_name="nope", sum_insured=5), headers=KEY).json["ok"])
        self.assertFalse(c.post("/api/bot/quote", json=dict(plan_id=1, sum_insured=-5), headers=KEY).json["ok"])
        self.assertEqual(c.get("/api/bot/verify/STC-NOPE", headers=KEY).json["code"], "NOT_FOUND")

    def test_private_needs_login_and_ignores_cookie(self):
        web, tok = self.login("client@portal.com", "Client@123", "client")
        r = web.get("/api/bot/invoices", headers=KEY).json           # cookie present, but no chat token -> must NOT work
        self.assertEqual(r["code"], "LOGIN_REQUIRED")
        self.assertEqual(self.app.test_client().get("/api/bot/invoices", headers={**KEY, "Authorization": "Bearer junk"}).json["code"], "BAD_TOKEN")

    def test_scope_follows_roles(self):
        c = self.app.test_client()
        _, client = self.login("client@portal.com", "Client@123", "client")
        _, other = self.login("demo1@portal.com", "Client@123", "client")
        _, admin = self.login("admin@portal.com", "Admin@123", "admin")
        mine = c.get("/api/bot/policies", headers=self.auth(client)).json; self.assertEqual(mine["count"], 1)
        self.assertEqual(c.get("/api/bot/policies", headers=self.auth(other)).json["count"], 0)       # another client sees nothing of Chris
        self.assertGreaterEqual(c.get("/api/bot/policies", headers=self.auth(admin)).json["count"], 1)
        inv = c.get("/api/bot/invoices", headers=self.auth(client)).json; self.assertEqual(inv["count"], 1)
        self.assertEqual(c.get("/api/bot/invoices", headers=self.auth(other)).json["count"], 0)
        self.assertEqual(c.get("/api/bot/documents", headers=self.auth(admin)).json["code"], "CLIENT_ONLY")
        self.assertEqual(len(c.get("/api/bot/documents", headers=self.auth(client)).json["required"]), 4)
        self.assertTrue(c.get("/api/bot/brokers", headers=self.auth(client)).json["brokers"])

    def test_certificates(self):
        c = self.app.test_client(); _, tok = self.login("client@portal.com", "Client@123", "client"); _, other = self.login("demo2@portal.com", "Client@123", "client")
        certs = c.get("/api/bot/certificates", headers=self.auth(tok)).json; self.assertEqual(certs["count"], 1)
        n = certs["certificates"][0]["number"] or "STC-MISSING"
        # the demo certificate is still 'Submitted' (no number yet) - an unknown number must be a clean "not found"
        self.assertEqual(c.get("/api/bot/certificates?number=STC-000000", headers=self.auth(tok)).json["code"], "NOT_FOUND")
        self.assertEqual(c.get("/api/bot/certificates", headers=self.auth(other)).json["count"], 0)

    def test_claim_flow_and_rules(self):
        c = self.app.test_client(); _, tok = self.login("client@portal.com", "Client@123", "client"); h = self.auth(tok)
        day = (dt.date.today() - dt.timedelta(5)).isoformat()
        body = dict(policy_number="MTP-2026-000001", incident_date=day, incident_type="Collision", description="Collision with a pier while berthing", amount_claimed=50000)
        r = c.post("/api/bot/claims", json=body, headers=h).json            # no CSRF header needed on /api/bot
        self.assertTrue(r["ok"], r); num = r["claim_number"]
        got = c.get("/api/bot/claims?number=" + num, headers=h).json; self.assertEqual(got["claims"][0]["status"], "Submitted")
        self.assertEqual(c.post("/api/bot/claims", json={**body, "amount_claimed": 999999999}, headers=h).json["code"], "CLAIM_REJECTED")
        self.assertEqual(c.post("/api/bot/claims", json={**body, "incident_date": "2999-01-01"}, headers=h).json["code"], "CLAIM_REJECTED")
        self.assertEqual(c.post("/api/bot/claims", json={**body, "policy_number": "MTP-NOPE"}, headers=h).json["code"], "POLICY_NOT_FOUND")
        _, other = self.login("demo3@portal.com", "Client@123", "client")
        self.assertEqual(c.post("/api/bot/claims", json=body, headers=self.auth(other)).json["code"], "POLICY_NOT_FOUND")   # cannot claim on someone else's policy
        self.assertEqual(c.get("/api/bot/claims?number=" + num, headers=self.auth(other)).json["code"], "NOT_FOUND")

    def test_website_still_needs_csrf(self):
        web, _ = self.login("client@portal.com", "Client@123", "client")
        self.assertEqual(web.post("/api/claims", json={}).status_code, 403)

    def test_expired_token(self):
        _, tok = self.login("client@portal.com", "Client@123", "client"); old = cg.COGNIGY_TOKEN_TTL; cg.COGNIGY_TOKEN_TTL = -1
        try: self.assertEqual(self.app.test_client().get("/api/bot/policies", headers=self.auth(tok)).json["code"], "TOKEN_EXPIRED")
        finally: cg.COGNIGY_TOKEN_TTL = old

    def test_handover(self):
        c = self.app.test_client()
        self.assertEqual(c.post("/api/bot/handover", json=dict(message="short"), headers=KEY).json["code"], "BAD_MESSAGE")
        self.assertEqual(c.post("/api/bot/handover", json=dict(message="I need a human for my claim please"), headers=KEY).json["code"], "BAD_EMAIL")
        self.assertTrue(c.post("/api/bot/handover", json=dict(message="I need a human for my claim please", email="a@b.co"), headers=KEY).json["ok"])
        admin, _ = self.login("admin@portal.com", "Admin@123", "admin"); msgs = admin.get("/api/messages").json
        self.assertIn("Chatbot", str(msgs))


if __name__ == "__main__": unittest.main(verbosity=2)
